#!/usr/bin/env python3
"""Smoothly fade an LED on GP15 using hardware PWM."""
import time
from pico_gpio import PicoGPIO

PIN_LED = 15

with PicoGPIO() as pico:
    print(f"Fading LED on GP{PIN_LED} via hardware PWM...")
    for cycle in range(3):
        # Fade Up
        for duty in range(0, 101, 5):
            pico.pwm(PIN_LED, freq=2000, duty=duty)
            time.sleep(0.03)
        # Fade Down
        for duty in range(100, -1, -5):
            pico.pwm(PIN_LED, freq=2000, duty=duty)
            time.sleep(0.03)
    pico.pwm_stop(PIN_LED)
    print("PWM Fade Complete!")
