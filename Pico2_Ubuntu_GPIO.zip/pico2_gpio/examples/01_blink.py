#!/usr/bin/env python3
"""Blink the onboard LED or external LED on GP15."""
import time
from pico_gpio import PicoGPIO

with PicoGPIO() as pico:
    print("Blinking Pico 2 onboard LED (Ctrl+C to stop)...")
    for i in range(10):
        pico.led(True)
        print(f"Cycle {i+1}: LED ON")
        time.sleep(0.3)
        pico.led(False)
        print(f"Cycle {i+1}: LED OFF")
        time.sleep(0.3)
    print("Done!")
