#!/usr/bin/env python3
"""Sweep a 50Hz RC Servo motor connected to GP14 from 0 to 180 degrees."""
import time
from pico_gpio import PicoGPIO

PIN_SERVO = 14

with PicoGPIO() as pico:
    print(f"Sweeping Servo on GP{PIN_SERVO}...")
    for angle in [0, 45, 90, 135, 180, 90, 0]:
        print(f"Moving to {angle}°")
        pico.servo(PIN_SERVO, angle)
        time.sleep(0.6)
    pico.pwm_stop(PIN_SERVO)
    print("Servo demo finished!")
