#!/usr/bin/env python3
"""Read a push button connected between GP14 and GND."""
import time
from pico_gpio import PicoGPIO, IN_PULLUP

PIN_BUTTON = 14

with PicoGPIO() as pico:
    pico.pin_mode(PIN_BUTTON, IN_PULLUP)
    print(f"Reading Button on GP{PIN_BUTTON} with internal pull-up (Ctrl+C to stop)...")
    last_state = -1
    for _ in range(50):
        state = pico.digital_read(PIN_BUTTON)
        if state != last_state:
            print(f"Button state: {'RELEASED (HIGH)' if state else 'PRESSED (LOW)'}")
            last_state = state
        time.sleep(0.1)
