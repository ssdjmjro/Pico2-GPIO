#!/usr/bin/env python3
"""Read analog potentiometer or sensor on GP26 (ADC0)."""
import time
from pico_gpio import PicoGPIO

with PicoGPIO() as pico:
    print("Reading ADC0 (GP26) and RP2350 core temperature...")
    for _ in range(10):
        raw = pico.analog_read(26)
        volts = pico.analog_read_voltage(26)
        temp = pico.get_internal_temp()
        print(f"ADC0 (GP26): Raw={raw:5d} | Voltage={volts:5.3f}V | Core Temp={temp:.2f}°C")
        time.sleep(0.5)
