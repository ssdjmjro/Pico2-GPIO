# Raspberry Pi Pico 2 (RP2350) GPIO Interface for Ubuntu

Use your **Raspberry Pi Pico 2** as a high-performance USB GPIO controller for Ubuntu Linux. Control digital I/O, hardware PWM, analog inputs (ADC), servos, and read core telemetry over USB.

---

## ⚡ Quick CLI Usage

You can control pins directly from your terminal using the `pico-gpio` command:

```bash
# Check connection, board frequency, and core temperature
pico-gpio status

# Onboard LED control
pico-gpio led on
pico-gpio led off
pico-gpio led toggle

# Digital Output (Set GP15 HIGH / 3.3V or LOW / 0V)
pico-gpio write 15 1
pico-gpio write 15 0

# Digital Input (Read GP16 with optional internal pull-up/pull-down)
pico-gpio read 16
pico-gpio read 16 --pull up

# Analog Input (Read ADC0 / GP26, GP27, GP28)
pico-gpio analog 26

# Hardware PWM (Set GP15 to 1 kHz at 50% duty cycle)
pico-gpio pwm 15 --freq 1000 --duty 50
pico-gpio pwm 15 --stop

# RC Servo (Move servo on GP14 to 90 degrees)
pico-gpio servo 14 90

# Core Temperature
pico-gpio temp

# Automated Board Self-Test
pico-gpio test
```

---

## 🐍 Python Library Usage (`import pico_gpio`)

The `pico_gpio` module is installed and available anywhere in your Python 3 environment.

### Basic Example:
```python
from pico_gpio import PicoGPIO, OUT, IN, IN_PULLUP
import time

# Auto-connects to connected Pico 2
with PicoGPIO() as pico:
    # Set Pin Mode
    pico.pin_mode(15, OUT)
    
    # Digital Output
    pico.digital_write(15, True)
    time.sleep(0.5)
    pico.digital_write(15, False)
    
    # Toggle Pin
    pico.toggle(15)
    
    # Read Digital Pin
    pico.pin_mode(16, IN_PULLUP)
    state = pico.digital_read(16)
    print("Pin 16:", state)
    
    # Read Analog ADC (0-3.3V)
    volts = pico.analog_read_voltage(26)
    print("ADC0 (GP26) Voltage:", volts)
    
    # Onboard LED
    pico.led(True)
    
    # Core Temp
    print("RP2350 Temp:", pico.get_internal_temp(), "°C")
```

---

## 📌 Pico 2 (RP2350) Pinout Reference

| Pin (GP) | Alternate Functions | Notes |
| :--- | :--- | :--- |
| **GP0 - GP22** | Digital I/O, PWM, UART, SPI, I2C | General purpose 3.3V logic pins |
| **GP25 / LED** | Onboard Green LED | Controlled via `pico.led(...)` |
| **GP26** | ADC0 / Digital I/O | Analog In Channel 0 (0-3.3V) |
| **GP27** | ADC1 / Digital I/O | Analog In Channel 1 (0-3.3V) |
| **GP28** | ADC2 / Digital I/O | Analog In Channel 2 (0-3.3V) |
| **ADC4 (Internal)**| Internal Temperature Sensor | Read via `pico.get_internal_temp()` |
| **3V3 (Pin 36)** | 3.3V Power Out | Power external sensors / circuits |
| **GND** | Ground (Pins 3, 8, 13, 18, 23, 28, 38)| Common ground reference |

---

## 📁 Included Examples

Check out the scripts in `examples/`:
- `examples/01_blink.py` - Blinking the LED
- `examples/02_button_reader.py` - Button polling with pull-ups
- `examples/03_pwm_fade.py` - PWM LED brightness fading
- `examples/04_analog_sensor.py` - Reading ADC voltage & temperature
- `examples/05_servo_control.py` - RC Servo motor position sweep
