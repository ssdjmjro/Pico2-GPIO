#!/usr/bin/env bash
# ==========================================================
# Flash MicroPython & Upload GPIO Bridge to Pico 2
# ==========================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN="\033[92m"
CYAN="\033[96m"
YELLOW="\033[93m"
RED="\033[91m"
BOLD="\033[1m"
RESET="\033[0m"

echo -e "${BOLD}${CYAN}⚡ Flashing Raspberry Pi Pico 2 with MicroPython GPIO Firmware...${RESET}"

# Check for UF2 file
UF2_FILE="$DIR/RPI_PICO2-v1.28.0.uf2"
if [ ! -f "$UF2_FILE" ]; then
    echo -e "${YELLOW}Downloading latest Pico 2 MicroPython firmware...${RESET}"
    curl -L -o "$UF2_FILE" https://micropython.org/resources/firmware/RPI_PICO2-20260406-v1.28.0.uf2
fi

# Find mount point
MOUNT_DIR=""
if [ -d "/run/media/$USER/RP2350" ]; then
    MOUNT_DIR="/run/media/$USER/RP2350"
elif [ -d "/run/media/$USER/RPI-RP2" ]; then
    MOUNT_DIR="/run/media/$USER/RPI-RP2"
elif [ -d "/media/$USER/RP2350" ]; then
    MOUNT_DIR="/media/$USER/RP2350"
elif [ -d "/media/$USER/RPI-RP2" ]; then
    MOUNT_DIR="/media/$USER/RPI-RP2"
fi

if [ -n "$MOUNT_DIR" ]; then
    echo -e "Copying UF2 firmware to ${BOLD}$MOUNT_DIR${RESET}..."
    cp "$UF2_FILE" "$MOUNT_DIR/"
    sync
    echo -e "${GREEN}✓ UF2 firmware flashed! Waiting for reboot...${RESET}"
    sleep 3
else
    echo -e "${YELLOW}Pico 2 is already running MicroPython or not in BOOTSEL mode.${RESET}"
fi

# Upload main.py to Pico 2 flash
echo -e "${CYAN}Uploading GPIO server (main.py) to Pico 2...${RESET}"
python3 - << 'PYEOF'
import serial, time, os, sys
import serial.tools.list_ports

def find_port():
    for p in serial.tools.list_ports.comports():
        if p.vid == 0x2E8A or (p.device and "/dev/ttyACM" in p.device):
            return p.device
    return "/dev/ttyACM0"

port = find_port()
print(f"Connecting to Pico 2 on {port}...")

with open("/home/ssdjmjro/pico2_gpio/main.py", "rb") as f:
    content = f.read()

ser = serial.Serial(port, 115200, timeout=2)
ser.dtr = True
ser.rts = False

# Enter raw REPL
ser.write(b'\x03\x03\x01')
time.sleep(0.2)
ser.reset_input_buffer()

ser.write(b'with open("main.py", "wb") as f:\n')
CHUNK_SIZE = 128
for i in range(0, len(content), CHUNK_SIZE):
    chunk = content[i:i+CHUNK_SIZE]
    ser.write(f'    f.write({repr(chunk)})\n'.encode('utf-8'))

ser.write(b'\x04')
time.sleep(0.5)
resp = ser.read_until(b'\x04>')

# Soft reboot
ser.write(b'\x02\x04')
time.sleep(0.5)
ser.close()
print("✓ main.py uploaded successfully!")
PYEOF

echo -e "${BOLD}${GREEN}✓ Pico 2 successfully flashed and configured!${RESET}"
