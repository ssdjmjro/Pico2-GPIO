#!/usr/bin/env bash
# ==========================================================
# 1-Click Push to GitHub Script
# ==========================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

GREEN="\033[92m"
CYAN="\033[96m"
YELLOW="\033[93m"
RED="\033[91m"
BOLD="\033[1m"
RESET="\033[0m"

echo -e "${BOLD}${CYAN}🚀 Pushing Pico 2 GPIO to GitHub...${RESET}"

# Check SSH authentication to GitHub
if ! ssh -o BatchMode=yes -o ConnectTimeout=5 -T git@github.com 2>&1 | grep -iq "successfully authenticated\|You've successfully authenticated"; then
    # If not authenticated yet via SSH, check if key is generated
    PUB_KEY="$HOME/.ssh/id_ed25519.pub"
    if [ -f "$PUB_KEY" ]; then
        echo -e "\n${BOLD}${YELLOW}⚠️  GitHub SSH Key needs to be added to your GitHub account:${RESET}"
        echo -e "1. Go to: ${CYAN}https://github.com/settings/ssh/new${RESET}"
        echo -e "2. Paste the following key as the 'Key':\n"
        echo -e "${BOLD}$(cat "$PUB_KEY")${RESET}\n"
        echo -e "3. Click ${BOLD}'Add SSH key'${RESET} and run this script again!"
        echo -e "${CYAN}------------------------------------------------${RESET}"
    fi
fi

# Stage all changes
git add .

# Check if there are changes to commit
if git diff-index --quiet HEAD --; then
    echo -e "${YELLOW}Working tree clean, pushing existing commits...${RESET}"
else
    MSG="${1:-Update Pico 2 GPIO controller $(date '+%Y-%m-%d %H:%M')}"
    git commit -m "$MSG"
fi

# Push
echo -e "${CYAN}Running git push...${RESET}"
git push -u origin main

echo -e "\n${BOLD}${GREEN}✓ Successfully pushed to GitHub: https://github.com/ssdjmjro/pico2-ubuntu-gpio${RESET}\n"
