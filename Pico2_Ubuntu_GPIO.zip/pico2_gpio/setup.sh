#!/usr/bin/env bash
# ==============================================================================
# Raspberry Pi Pico 2 - Ubuntu GPIO Automated Setup & Recognition Installer
# ==============================================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN="\033[92m"
CYAN="\033[96m"
YELLOW="\033[93m"
RED="\033[91m"
BOLD="\033[1m"
RESET="\033[0m"

echo -e "${BOLD}${CYAN}==================================================================${RESET}"
echo -e "${BOLD}${CYAN}   ⚡ Raspberry Pi Pico 2 -> Ubuntu GPIO Setup & Installer       ${RESET}"
echo -e "${BOLD}${CYAN}==================================================================${RESET}"

# Step 1: Install Python dependencies
echo -e "\n${BOLD}[1/4] Checking Python environment...${RESET}"
python3 -c "import serial" 2>/dev/null || {
    echo -e "${YELLOW}Installing pyserial...${RESET}"
    pip install pyserial || pip3 install pyserial --break-system-packages
}
echo -e "${GREEN}✓ Python pyserial is installed.${RESET}"

# Step 2: Install udev recognition rules
echo -e "\n${BOLD}[2/4] Configuring USB plug-and-play recognition rules...${RESET}"
if [ -w "/etc/udev/rules.d" ]; then
    cp "$DIR/99-pico-gpio.rules" /etc/udev/rules.d/
    udevadm control --reload-rules 2>/dev/null && udevadm trigger 2>/dev/null || true
    echo -e "${GREEN}✓ udev rules installed directly to /etc/udev/rules.d/${RESET}"
else
    echo -e "${YELLOW}Notice: To enable plug-and-play udev permissions across all users, run:${RESET}"
    echo -e "  ${BOLD}sudo cp $DIR/99-pico-gpio.rules /etc/udev/rules.d/ && sudo udevadm control --reload-rules${RESET}"
fi

# Step 3: Install CLI tools & Python library
echo -e "\n${BOLD}[3/4] Installing pico-gpio command and Python module...${RESET}"
mkdir -p "$HOME/.local/bin"
PY_USER_SITE="$(python3 -c 'import site; print(site.getusersitepackages())')"
mkdir -p "$PY_USER_SITE"

cp -f "$DIR/pico_gpio.py" "$PY_USER_SITE/"
rm -f "$HOME/.local/bin/pico-gpio"
cp -f "$DIR/pico-gpio" "$HOME/.local/bin/pico-gpio"
chmod +x "$HOME/.local/bin/pico-gpio"

echo -e "${GREEN}✓ 'pico-gpio' CLI installed to $HOME/.local/bin/pico-gpio${RESET}"
echo -e "${GREEN}✓ 'pico_gpio' Python module installed to $PY_USER_SITE${RESET}"

# Step 4: Flash / Connect to Pico 2
echo -e "\n${BOLD}[4/4] Activating Pico 2 GPIO...${RESET}"
if [ -d "/run/media/$USER/RP2350" ] || [ -d "/run/media/$USER/RPI-RP2" ] || [ -d "/media/$USER/RP2350" ] || [ -d "/media/$USER/RPI-RP2" ]; then
    echo -e "${YELLOW}Pico 2 detected in bootloader mode. Flashing firmware...${RESET}"
    bash "$DIR/flash_pico2.sh"
fi

if python3 "$DIR/pico-gpio" test; then
    echo -e "\n${BOLD}${GREEN}==================================================================${RESET}"
    echo -e "${BOLD}${GREEN}   ✓ SETUP COMPLETE! Pico 2 is recognized as Ubuntu GPIO!        ${RESET}"
    echo -e "${BOLD}${GREEN}==================================================================${RESET}"
    echo -e "\nYou can now control pins anytime from your terminal:"
    echo -e "  ${BOLD}pico-gpio status${RESET}                 # Show connection & core temp"
    echo -e "  ${BOLD}pico-gpio led on / off / toggle${RESET}  # Control onboard LED"
    echo -e "  ${BOLD}pico-gpio write 15 1${RESET}             # Set GP15 to 3.3V"
    echo -e "  ${BOLD}pico-gpio read 16${RESET}                # Read GP16 digital input"
    echo -e "  ${BOLD}pico-gpio analog 26${RESET}              # Read GP26 ADC voltage (0-3.3V)"
    echo -e "  ${BOLD}pico-gpio pwm 15 -f 1000 -d 50${RESET}   # 1kHz PWM at 50% duty"
    echo -e "  ${BOLD}pico-gpio test${RESET}                   # Run diagnostic self-test\n"
else
    echo -e "\n${YELLOW}Setup finished. Please plug in your Pico 2 via USB and run 'pico-gpio test'${RESET}"
fi
