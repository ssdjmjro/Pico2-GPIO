# Pico 2 GPIO Serial Server
# Runs on Raspberry Pi Pico 2 (RP2350) MicroPython
import sys
import os
import machine
import time
import select

VERSION = "1.0.0-RP2350"

pins = {}
pwms = {}
adcs = {}

def get_led_pin():
    try:
        return machine.Pin("LED", machine.Pin.OUT)
    except Exception:
        try:
            return machine.Pin(25, machine.Pin.OUT)
        except Exception:
            return None

led_obj = get_led_pin()

def resolve_pin_id(p_str):
    p_str = p_str.strip().upper()
    if p_str == "LED":
        return "LED"
    if p_str.startswith("GP"):
        p_str = p_str[2:]
    return int(p_str)

def handle_pin_mode(parts):
    # PIN_MODE <pin> <IN|OUT|IN_PULLUP|IN_PULLDOWN>
    if len(parts) < 3:
        return "ERR: Invalid args. Usage: PIN_MODE <pin> <mode>"
    pin_id = resolve_pin_id(parts[1])
    mode_str = parts[2].upper()
    
    if pin_id in pwms:
        try:
            pwms[pin_id].deinit()
        except:
            pass
        del pwms[pin_id]
        
    if mode_str == "OUT":
        p = machine.Pin("LED", machine.Pin.OUT) if pin_id == "LED" else machine.Pin(pin_id, machine.Pin.OUT)
    elif mode_str == "IN":
        p = machine.Pin(pin_id, machine.Pin.IN)
    elif mode_str in ("IN_PULLUP", "PULL_UP", "PULLUP"):
        p = machine.Pin(pin_id, machine.Pin.IN, machine.Pin.PULL_UP)
    elif mode_str in ("IN_PULLDOWN", "PULL_DOWN", "PULLDOWN"):
        p = machine.Pin(pin_id, machine.Pin.IN, machine.Pin.PULL_DOWN)
    else:
        return "ERR: Unknown mode. Use IN, OUT, IN_PULLUP, IN_PULLDOWN"
        
    pins[pin_id] = p
    return f"OK: PIN_MODE {pin_id} {mode_str}"

def handle_digital_write(parts):
    # DIGITAL_WRITE <pin> <0|1>
    if len(parts) < 3:
        return "ERR: Invalid args. Usage: DIGITAL_WRITE <pin> <0|1>"
    pin_id = resolve_pin_id(parts[1])
    val = 1 if parts[2] in ("1", "HIGH", "TRUE", "ON", "true", "on") else 0
    
    if pin_id not in pins:
        p = machine.Pin("LED", machine.Pin.OUT) if pin_id == "LED" else machine.Pin(pin_id, machine.Pin.OUT)
        pins[pin_id] = p
    else:
        p = pins[pin_id]
        
    p.value(val)
    return f"OK: DIGITAL_WRITE {pin_id} {val}"

def handle_digital_read(parts):
    # DIGITAL_READ <pin>
    if len(parts) < 2:
        return "ERR: Invalid args. Usage: DIGITAL_READ <pin>"
    pin_id = resolve_pin_id(parts[1])
    if pin_id not in pins:
        p = machine.Pin("LED", machine.Pin.IN) if pin_id == "LED" else machine.Pin(pin_id, machine.Pin.IN)
        pins[pin_id] = p
    else:
        p = pins[pin_id]
        
    return f"VAL:{p.value()}"

def handle_toggle(parts):
    # TOGGLE <pin>
    if len(parts) < 2:
        return "ERR: Invalid args. Usage: TOGGLE <pin>"
    pin_id = resolve_pin_id(parts[1])
    if pin_id not in pins:
        p = machine.Pin("LED", machine.Pin.OUT) if pin_id == "LED" else machine.Pin(pin_id, machine.Pin.OUT)
        pins[pin_id] = p
    else:
        p = pins[pin_id]
    new_val = 0 if p.value() else 1
    p.value(new_val)
    return f"VAL:{new_val}"

def handle_analog_read(parts):
    # ANALOG_READ <pin>
    if len(parts) < 2:
        return "ERR: Invalid args. Usage: ANALOG_READ <pin>"
    pin_id = parts[1].strip().upper()
    if pin_id in ("TEMP", "TEMPERATURE", "4"):
        adc = machine.ADC(4)
        raw = adc.read_u16()
        voltage = raw * (3.3 / 65535)
        temp_c = 27.0 - (voltage - 0.706) / 0.001721
        return f"TEMP:{temp_c:.2f},RAW:{raw},VOLTS:{voltage:.4f}"
    else:
        pid = resolve_pin_id(pin_id)
        if pid not in adcs:
            adcs[pid] = machine.ADC(pid)
        adc = adcs[pid]
        raw = adc.read_u16()
        voltage = raw * (3.3 / 65535)
        return f"RAW:{raw},VOLTS:{voltage:.4f}"

def handle_pwm(parts):
    # PWM <pin> <freq_hz> <duty_percent_or_u16>
    if len(parts) < 4:
        return "ERR: Invalid args. Usage: PWM <pin> <freq> <duty>"
    pin_id = resolve_pin_id(parts[1])
    freq = int(float(parts[2]))
    duty_arg = float(parts[3])
    
    if duty_arg <= 100.0:
        duty_u16 = int((duty_arg / 100.0) * 65535)
    else:
        duty_u16 = int(duty_arg)
        
    duty_u16 = max(0, min(65535, duty_u16))
    
    if pin_id not in pwms:
        p = machine.Pin(pin_id)
        pwm = machine.PWM(p)
        pwms[pin_id] = pwm
    else:
        pwm = pwms[pin_id]
        
    pwm.freq(freq)
    pwm.duty_u16(duty_u16)
    return f"OK: PWM {pin_id} FREQ={freq} DUTY={duty_u16}"

def handle_pwm_stop(parts):
    if len(parts) < 2:
        return "ERR: Invalid args. Usage: PWM_STOP <pin>"
    pin_id = resolve_pin_id(parts[1])
    if pin_id in pwms:
        pwms[pin_id].deinit()
        del pwms[pin_id]
        return f"OK: PWM_STOP {pin_id}"
    return f"OK: PWM {pin_id} was not active"

def handle_servo(parts):
    if len(parts) < 3:
        return "ERR: Invalid args. Usage: SERVO <pin> <angle_deg>"
    pin_id = resolve_pin_id(parts[1])
    angle = float(parts[2])
    angle = max(0.0, min(180.0, angle))
    min_duty = 1638
    max_duty = 8192
    duty_u16 = int(min_duty + (angle / 180.0) * (max_duty - min_duty))
    
    if pin_id not in pwms:
        p = machine.Pin(pin_id)
        pwm = machine.PWM(p)
        pwms[pin_id] = pwm
    else:
        pwm = pwms[pin_id]
        
    pwm.freq(50)
    pwm.duty_u16(duty_u16)
    return f"OK: SERVO {pin_id} ANGLE={angle:.1f}"

def handle_led(parts):
    if len(parts) < 2:
        return "ERR: Usage: LED <ON|OFF|TOGGLE>"
    action = parts[1].upper()
    global led_obj
    if led_obj is None:
        led_obj = get_led_pin()
    if led_obj is None:
        return "ERR: Onboard LED pin not found"
        
    if action in ("ON", "1", "HIGH", "TRUE"):
        led_obj.value(1)
        return "OK: LED 1"
    elif action in ("OFF", "0", "LOW", "FALSE"):
        led_obj.value(0)
        return "OK: LED 0"
    elif action in ("TOGGLE", "TOG"):
        nv = 0 if led_obj.value() else 1
        led_obj.value(nv)
        return f"OK: LED {nv}"
    else:
        return "ERR: Unknown LED state"

def handle_info():
    temp_adc = machine.ADC(4)
    raw = temp_adc.read_u16()
    voltage = raw * (3.3 / 65535)
    temp_c = 27.0 - (voltage - 0.706) / 0.001721
    return f"INFO: PLATFORM={sys.platform}, VERSION={VERSION}, FREQ={machine.freq()}, TEMP={temp_c:.1f}C, ACTIVE_PINS={list(pins.keys())}, PWM_PINS={list(pwms.keys())}"

def process_command(line):
    line = line.strip()
    if not line:
        return ""
    parts = line.split()
    cmd = parts[0].upper()
    
    try:
        if cmd == "PING":
            return "PONG"
        elif cmd in ("INFO", "STATUS"):
            return handle_info()
        elif cmd == "PIN_MODE":
            return handle_pin_mode(parts)
        elif cmd in ("DIGITAL_WRITE", "WRITE"):
            return handle_digital_write(parts)
        elif cmd in ("DIGITAL_READ", "READ"):
            return handle_digital_read(parts)
        elif cmd == "TOGGLE":
            return handle_toggle(parts)
        elif cmd in ("ANALOG_READ", "ADC"):
            return handle_analog_read(parts)
        elif cmd == "PWM":
            return handle_pwm(parts)
        elif cmd == "PWM_STOP":
            return handle_pwm_stop(parts)
        elif cmd == "SERVO":
            return handle_servo(parts)
        elif cmd == "LED":
            return handle_led(parts)
        elif cmd in ("RESET", "REBOOT"):
            machine.reset()
            return "OK: REBOOTING"
        elif cmd in ("EXIT", "REPL"):
            return "EXIT: REPL"
        else:
            return f"ERR: Unknown command '{cmd}'"
    except Exception as e:
        return f"ERR: {e}"

def main():
    if led_obj:
        for _ in range(2):
            led_obj.value(1)
            time.sleep(0.08)
            led_obj.value(0)
            time.sleep(0.08)
            
    sys.stdout.write(f"\n[PICO2_GPIO_READY: {VERSION}]\n")
    
    poll = select.poll()
    poll.register(sys.stdin, select.POLLIN)
    
    buf = ""
    while True:
        events = poll.poll(100)
        if events:
            ch = sys.stdin.read(1)
            if not ch:
                continue
            if ch in ("\r", "\n"):
                if buf.strip():
                    resp = process_command(buf)
                    if resp == "EXIT: REPL":
                        sys.stdout.write("Exiting to REPL...\n")
                        break
                    sys.stdout.write(resp + "\n")
                buf = ""
            elif ch == "\x03":
                break
            else:
                buf += ch

if __name__ == "__main__":
    main()
