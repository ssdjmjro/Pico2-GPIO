#!/usr/bin/env bash
# ==========================================================
# Pico 2 GPIO Safe Deactivation & Disarm Script
# ==========================================================
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN="\033[92m"
CYAN="\033[96m"
YELLOW="\033[93m"
BOLD="\033[1m"
RESET="\033[0m"

echo -e "${BOLD}${YELLOW}Safely deactivating Pico 2 GPIO...${RESET}"

python3 - << 'PYEOF'
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pico_gpio import PicoGPIO, IN

try:
    with PicoGPIO() as pico:
        # Turn off LED
        pico.led(False)
        
        # Stop all PWMs and park pins
        for pin in range(29):
            try:
                pico.pwm_stop(pin)
                pico.pin_mode(pin, IN)
            except Exception:
                pass
                
        print("✓ All GPIO pins set to safe high-impedance input mode.")
        print("✓ All PWM channels stopped.")
        print("✓ Onboard LED turned off.")
except Exception as e:
    print(f"Notice during deactivation: {e}")
PYEOF

echo -e "${BOLD}${GREEN}✓ Pico 2 GPIO safely DEACTIVATED / PARKED.${RESET}"
