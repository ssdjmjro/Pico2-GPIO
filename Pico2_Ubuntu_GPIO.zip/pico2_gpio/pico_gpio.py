"""
Pico 2 GPIO Controller for Ubuntu Linux
Control Raspberry Pi Pico 2 (RP2350) GPIO pins directly over USB Serial.
"""

import sys
import time
import serial
import serial.tools.list_ports

# Pin Modes
IN = "IN"
OUT = "OUT"
IN_PULLUP = "IN_PULLUP"
IN_PULLDOWN = "IN_PULLDOWN"
PULL_UP = IN_PULLUP
PULL_DOWN = IN_PULLDOWN

# Logic Levels
HIGH = 1
LOW = 0

class PicoGPIOError(Exception):
    pass

class PicoGPIO:
    """Raspberry Pi Pico 2 USB GPIO Controller interface."""
    
    # Raspberry Pi Pico / RP2350 USB VID
    PICO_VID = 0x2E8A
    
    def __init__(self, port=None, baudrate=115200, timeout=1.0, auto_connect=True):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.ser = None
        if auto_connect:
            self.connect()
            
    @classmethod
    def find_pico_port(cls):
        """Automatically find connected Raspberry Pi Pico 2 serial port."""
        ports = serial.tools.list_ports.comports()
        
        # Priority 1: Check by Raspberry Pi VID
        for p in ports:
            if p.vid == cls.PICO_VID:
                return p.device
                
        # Priority 2: Check by description
        for p in ports:
            desc = (p.description or "").lower()
            if "micropython" in desc or "pico" in desc or "rp2350" in desc:
                return p.device
                
        # Priority 3: Check /dev/ttyACM*
        for p in ports:
            if p.device and p.device.startswith("/dev/ttyACM"):
                return p.device
                
        return None

    def connect(self):
        """Open connection to the Pico 2."""
        if not self.port:
            self.port = self.find_pico_port()
            if not self.port:
                raise PicoGPIOError("Raspberry Pi Pico 2 not found! Please check USB cable connection.")
                
        try:
            self.ser = serial.Serial(self.port, self.baudrate, timeout=self.timeout)
            self.ser.dtr = True
            self.ser.rts = False
            time.sleep(0.05)
            
            # Verify communication
            if not self.ping():
                # Try waking up the serial server
                self.ser.write(b"\r\n")
                time.sleep(0.05)
                if not self.ping():
                    raise PicoGPIOError(f"Connected to {self.port} but Pico 2 GPIO server did not respond to PING.")
        except serial.SerialException as e:
            raise PicoGPIOError(f"Failed to open port {self.port}: {e}")

    def send_command(self, cmd_str):
        """Send a raw command string and return the response."""
        if not self.ser or not self.ser.is_open:
            raise PicoGPIOError("Serial port is not open.")
            
        self.ser.reset_input_buffer()
        self.ser.write((cmd_str.strip() + "\n").encode("utf-8"))
        
        line = self.ser.readline().decode("utf-8", errors="replace").strip()
        if not line:
            # Retry once
            time.sleep(0.05)
            line = self.ser.readline().decode("utf-8", errors="replace").strip()
            
        if line.startswith("ERR:"):
            raise PicoGPIOError(line)
        return line

    def ping(self):
        """Send PING to check responsiveness."""
        try:
            resp = self.send_command("PING")
            return resp == "PONG"
        except Exception:
            return False

    def pin_mode(self, pin, mode=OUT):
        """Set GPIO pin mode (IN, OUT, IN_PULLUP, IN_PULLDOWN)."""
        mode_str = str(mode).upper()
        return self.send_command(f"PIN_MODE {pin} {mode_str}")

    def setup(self, pin, mode=OUT):
        """RPi.GPIO compatibility alias for pin_mode."""
        return self.pin_mode(pin, mode)

    def digital_write(self, pin, value):
        """Set GPIO pin output value (HIGH/LOW or 1/0)."""
        val_int = 1 if value in (1, True, "1", "HIGH", "high", "ON", "on") else 0
        return self.send_command(f"DIGITAL_WRITE {pin} {val_int}")

    def output(self, pin, value):
        """RPi.GPIO compatibility alias for digital_write."""
        return self.digital_write(pin, value)

    def digital_read(self, pin):
        """Read digital value of GPIO pin (returns 0 or 1)."""
        resp = self.send_command(f"DIGITAL_READ {pin}")
        if resp.startswith("VAL:"):
            return int(resp.split(":")[1])
        return 0

    def input(self, pin):
        """RPi.GPIO compatibility alias for digital_read."""
        return self.digital_read(pin)

    def toggle(self, pin):
        """Toggle digital pin state and return new value."""
        resp = self.send_command(f"TOGGLE {pin}")
        if resp.startswith("VAL:"):
            return int(resp.split(":")[1])
        return 0

    def led(self, state=None):
        """Control or toggle onboard LED. Pass True/1 for ON, False/0 for OFF, None to TOGGLE."""
        if state is None:
            return self.send_command("LED TOGGLE")
        elif state in (True, 1, "ON", "on", "1"):
            return self.send_command("LED ON")
        else:
            return self.send_command("LED OFF")

    def analog_read(self, pin):
        """Read 16-bit raw ADC value (0-65535) on GP26 (ADC0), GP27 (ADC1), GP28 (ADC2)."""
        resp = self.send_command(f"ANALOG_READ {pin}")
        # returns RAW:xxxx,VOLTS:x.xxxx
        parts = dict(item.split(":") for item in resp.split(","))
        return int(parts.get("RAW", 0))

    def analog_read_voltage(self, pin):
        """Read analog voltage (0.0V - 3.3V) on GP26, GP27, GP28."""
        resp = self.send_command(f"ANALOG_READ {pin}")
        parts = dict(item.split(":") for item in resp.split(","))
        return float(parts.get("VOLTS", 0.0))

    def get_internal_temp(self):
        """Read Pico 2 onboard RP2350 internal temperature in Celsius."""
        resp = self.send_command("ANALOG_READ TEMP")
        parts = dict(item.split(":") for item in resp.split(","))
        return float(parts.get("TEMP", 0.0))

    def pwm(self, pin, freq=1000, duty=50.0):
        """Set PWM frequency (Hz) and duty cycle (0-100% or 0-65535)."""
        return self.send_command(f"PWM {pin} {freq} {duty}")

    def pwm_stop(self, pin):
        """De-initialize and stop PWM on pin."""
        return self.send_command(f"PWM_STOP {pin}")

    def servo(self, pin, angle_deg):
        """Control standard 50Hz RC servo motor (angle 0.0 to 180.0 degrees)."""
        return self.send_command(f"SERVO {pin} {angle_deg}")

    def get_info(self):
        """Get board status, CPU frequency, active pin list, and diagnostics."""
        resp = self.send_command("STATUS")
        return resp

    def close(self):
        """Close serial connection."""
        if self.ser and self.ser.is_open:
            self.ser.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
