#!/usr/bin/env bash
# ==========================================================
# Pico 2 GPIO Activation Script
# ==========================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN="\033[92m"
CYAN="\033[96m"
YELLOW="\033[93m"
RED="\033[91m"
BOLD="\033[1m"
RESET="\033[0m"

echo -e "${BOLD}${CYAN}================================================${RESET}"
echo -e "${BOLD}${CYAN}   ⚡ Pico 2 (RP2350) Ubuntu GPIO Activation    ${RESET}"
echo -e "${BOLD}${CYAN}================================================${RESET}"

# Check if Pico 2 is in BOOTSEL mode
if [ -d "/run/media/$USER/RP2350" ] || [ -d "/run/media/$USER/RPI-RP2" ]; then
    echo -e "${YELLOW}Pico 2 is in BOOTLOADER mode. Flashing firmware...${RESET}"
    bash "$DIR/flash_pico2.sh"
    sleep 2
fi

# Run diagnostics and self-test
echo -e "${CYAN}Checking connection and activating GPIO controller...${RESET}"
if python3 "$DIR/pico-gpio" test; then
    echo -e "${BOLD}${GREEN}✓ Pico 2 GPIO is now ACTIVATED and ready for use!${RESET}"
    echo -e "You can now run commands like:"
    echo -e "  ${BOLD}pico-gpio status${RESET}"
    echo -e "  ${BOLD}pico-gpio led on${RESET}"
    echo -e "  ${BOLD}pico-gpio write <pin> <1|0>${RESET}"
    echo -e "  ${BOLD}pico-gpio read <pin>${RESET}"
else
    echo -e "${RED}✗ Failed to activate Pico 2. Please check USB connection.${RESET}"
    exit 1
fi
