# ⚡ Raspberry Pi Pico 2 (RP2350) GPIO Studio for Ubuntu

Turn your **Raspberry Pi Pico 2** into a high-performance, user-friendly USB GPIO controller and hardware lab for Ubuntu Linux.

Featuring **Pico GPIO Studio (Native GTK 4 / Libadwaita Desktop App)** and **Web Studio Dashboard**, you can control digital I/O, hardware PWM, analog inputs (ADC with real-time oscilloscope), RC servos, I2C peripherals, automation macros, and system telemetry with an intuitive visual interface!

---

## 🚀 Launching the App (3 Easy Ways!)

### 1. Ubuntu Application Menu (GUI)
- Open your Ubuntu App Launcher and search for **"Pico GPIO Studio"** or double-click the icon on your **Desktop**.

### 2. Terminal Launcher
```bash
# Launch Native Desktop App (GTK 4 / Libadwaita)
pico-studio
# or
pico-gpio gui

# Launch Web Dashboard (Browser on http://localhost:5500)
pico-web
# or
pico-gpio web
```

---

## ✨ Features

- 📌 **Interactive 40-Pin DIP Board View**: Click any pin to inspect capabilities (PWM, ADC, I2C, SPI, UART) and toggle states in real time with glowing indicators.
- ⚡ **Digital Output Studio**: One-click HIGH/LOW toggles, timed pulse generators (50ms - 1s), and continuous blinker.
- 📥 **Digital Input Monitor**: Live logic level badges with selectable internal pull-up / pull-down / floating resistors.
- 🌊 **Hardware PWM Generator**: 1 Hz to 100 kHz frequency control, 0-100% duty cycle, quick presets, and live animated square waveform graph.
- 🦾 **RC Servo Motor Tuner**: Smooth 0° to 180° angle dial, quick preset angles, and automated back-and-forth sweep testing.
- 📈 **Real-Time ADC Oscilloscope**: Large digital voltmeter (0.000V - 3.300V), 16-bit raw values, and rolling trace with Min/Max/Vpp statistics.
- ⚡ **Step-by-Step Automation & Sequencer**: Visual macro runner to execute test scripts (Knight Rider LED scanner, PWM fader, Servo sweep) without writing code!
- 🔍 **I2C Bus & Sensor Scanner**: 16x8 hex address matrix with automatic identification of common modules (PN532 NFC, OLED displays, BMP280, MPU6050, etc.).
- 📊 **RP2350 Telemetry & Self-Test**: Live CPU die temperature, clock frequency (150 MHz), and automated 4-stage hardware diagnostics.
- 🛑 **Emergency All-Off / Safe Stop**: Instantly zero all outputs, stop PWM, and safely park all pins.
- 🔮 **Virtual Simulation Mode**: Test all features, sequencers, and pin diagrams even when offline or disconnected!

---

## ⚡ Quick CLI Usage

You can also control pins directly from your terminal using `pico-gpio`:

```bash
# Launch GUI Studio
pico-gpio studio
# Launch Web Dashboard
pico-gpio web

# Check connection, board frequency, and core temperature
pico-gpio status

# Onboard LED control
pico-gpio led on
pico-gpio led off
pico-gpio led toggle

# Digital Output (Set GP15 HIGH / 3.3V or LOW / 0V)
pico-gpio write 15 1
pico-gpio write 15 0

# Digital Input (Read GP16 with optional internal pull-up/pull-down)
pico-gpio read 16
pico-gpio read 16 --pull up

# Analog Input (Read ADC0 / GP26, GP27, GP28)
pico-gpio analog 26

# Hardware PWM (Set GP15 to 1 kHz at 50% duty cycle)
pico-gpio pwm 15 --freq 1000 --duty 50
pico-gpio pwm 15 --stop

# RC Servo (Move servo on GP14 to 90 degrees)
pico-gpio servo 14 90

# Scan I2C Devices
pico-gpio i2c --sda 4 --scl 5

# Core Temperature
pico-gpio temp

# Automated Board Self-Test
pico-gpio test
```

---

## 🐍 Python Library Usage (`import pico_gpio`)

The `pico_gpio` module is installed and available anywhere in your Python 3 environment.

### Basic Example:
```python
from pico_gpio import PicoGPIO, OUT, IN, IN_PULLUP
import time

# Auto-connects to connected Pico 2
with PicoGPIO() as pico:
    # Set Pin Mode
    pico.pin_mode(15, OUT)
    
    # Digital Output
    pico.digital_write(15, True)
    time.sleep(0.5)
    pico.digital_write(15, False)
    
    # Toggle Pin
    pico.toggle(15)
    
    # Read Digital Pin
    pico.pin_mode(16, IN_PULLUP)
    state = pico.digital_read(16)
    print("Pin 16:", state)
    
    # Read Analog ADC (0-3.3V)
    volts = pico.analog_read_voltage(26)
    print("ADC0 (GP26) Voltage:", volts)
    
    # Onboard LED
    pico.led(True)
    
    # Core Temp
    print("RP2350 Temp:", pico.get_internal_temp(), "°C")
```

---

## 📌 Pico 2 (RP2350) Pinout Reference

| Pin (GP) | Alternate Functions | Notes |
| :--- | :--- | :--- |
| **GP0 - GP22** | Digital I/O, PWM, UART, SPI, I2C | General purpose 3.3V logic pins |
| **GP25 / LED** | Onboard Green LED | Controlled via `pico.led(...)` |
| **GP26** | ADC0 / Digital I/O | Analog In Channel 0 (0-3.3V) |
| **GP27** | ADC1 / Digital I/O | Analog In Channel 1 (0-3.3V) |
| **GP28** | ADC2 / Digital I/O | Analog In Channel 2 (0-3.3V) |
| **ADC4 (Internal)**| Internal Temperature Sensor | Read via `pico.get_internal_temp()` |
| **3V3 (Pin 36)** | 3.3V Power Out | Power external sensors / circuits |
| **GND** | Ground (Pins 3, 8, 13, 18, 23, 28, 38)| Common ground reference |

---

## 📁 Included Examples

Check out the scripts in `examples/`:
- `examples/01_blink.py` - Blinking the LED
- `examples/02_button_reader.py` - Button polling with pull-ups
- `examples/03_pwm_fade.py` - PWM LED brightness fading
- `examples/04_analog_sensor.py` - Reading ADC voltage & temperature
- `examples/05_servo_control.py` - RC Servo motor position sweep
