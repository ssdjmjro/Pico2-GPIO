"""
Pico Automation & Sequence Lab View
Visual step-by-step macro runner and automation builder.
"""

import json
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib


PRESET_SEQUENCES = {
    "Knight Rider LED Scanner (GP0 to GP7)": [
        {'action': 'WRITE', 'pin': 0, 'val': 1, 'delay_ms': 80, 'desc': 'Turn on GP0'},
        {'action': 'WRITE', 'pin': 0, 'val': 0, 'delay_ms': 20, 'desc': 'Turn off GP0'},
        {'action': 'WRITE', 'pin': 1, 'val': 1, 'delay_ms': 80, 'desc': 'Turn on GP1'},
        {'action': 'WRITE', 'pin': 1, 'val': 0, 'delay_ms': 20, 'desc': 'Turn off GP1'},
        {'action': 'WRITE', 'pin': 2, 'val': 1, 'delay_ms': 80, 'desc': 'Turn on GP2'},
        {'action': 'WRITE', 'pin': 2, 'val': 0, 'delay_ms': 20, 'desc': 'Turn off GP2'},
        {'action': 'WRITE', 'pin': 3, 'val': 1, 'delay_ms': 80, 'desc': 'Turn on GP3'},
        {'action': 'WRITE', 'pin': 3, 'val': 0, 'delay_ms': 20, 'desc': 'Turn off GP3'},
        {'action': 'WRITE', 'pin': 2, 'val': 1, 'delay_ms': 80, 'desc': 'Turn on GP2'},
        {'action': 'WRITE', 'pin': 2, 'val': 0, 'delay_ms': 20, 'desc': 'Turn off GP2'},
        {'action': 'WRITE', 'pin': 1, 'val': 1, 'delay_ms': 80, 'desc': 'Turn on GP1'},
        {'action': 'WRITE', 'pin': 1, 'val': 0, 'delay_ms': 20, 'desc': 'Turn off GP1'},
    ],
    "PWM Breathing Light (GP15)": [
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 5.0, 'delay_ms': 50, 'desc': 'PWM 5%'},
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 20.0, 'delay_ms': 50, 'desc': 'PWM 20%'},
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 40.0, 'delay_ms': 50, 'desc': 'PWM 40%'},
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 70.0, 'delay_ms': 50, 'desc': 'PWM 70%'},
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 100.0, 'delay_ms': 100, 'desc': 'PWM 100% Peak'},
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 70.0, 'delay_ms': 50, 'desc': 'PWM 70%'},
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 40.0, 'delay_ms': 50, 'desc': 'PWM 40%'},
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 20.0, 'delay_ms': 50, 'desc': 'PWM 20%'},
        {'action': 'PWM', 'pin': 15, 'freq': 1000, 'duty': 0.0, 'delay_ms': 100, 'desc': 'PWM 0% Low'},
    ],
    "RC Servo Position Sweep (GP14)": [
        {'action': 'SERVO', 'pin': 14, 'angle': 0, 'delay_ms': 400, 'desc': 'Move to 0° Min'},
        {'action': 'SERVO', 'pin': 14, 'angle': 45, 'delay_ms': 300, 'desc': 'Move to 45°'},
        {'action': 'SERVO', 'pin': 14, 'angle': 90, 'delay_ms': 300, 'desc': 'Move to 90° Center'},
        {'action': 'SERVO', 'pin': 14, 'angle': 135, 'delay_ms': 300, 'desc': 'Move to 135°'},
        {'action': 'SERVO', 'pin': 14, 'angle': 180, 'delay_ms': 400, 'desc': 'Move to 180° Max'},
        {'action': 'SERVO', 'pin': 14, 'angle': 90, 'delay_ms': 300, 'desc': 'Return to 90° Center'},
    ],
    "Onboard LED Heartbeat": [
        {'action': 'LED', 'val': 1, 'delay_ms': 120, 'desc': 'LED Pulse 1'},
        {'action': 'LED', 'val': 0, 'delay_ms': 100, 'desc': 'LED Gap'},
        {'action': 'LED', 'val': 1, 'delay_ms': 120, 'desc': 'LED Pulse 2'},
        {'action': 'LED', 'val': 0, 'delay_ms': 700, 'desc': 'Heartbeat Rest'},
    ]
}


class SequencerView(Gtk.Box):
    def __init__(self, backend):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.backend = backend
        self.set_margin_top(12)
        self.set_margin_bottom(12)
        self.set_margin_start(16)
        self.set_margin_end(16)
        
        self.steps = list(PRESET_SEQUENCES["Knight Rider LED Scanner (GP0 to GP7)"])
        self.step_rows = []
        
        self._build_ui()
        self._refresh_step_list()

    def _build_ui(self):
        # Top Controls Card
        ctrl_group = Adw.PreferencesGroup()
        ctrl_group.set_title("Automation &amp; Macro Controls")
        ctrl_group.set_description("Execute repeatable test sequences, hardware diagnostics, and robotics routines.")
        
        # Action Toolbar Row
        action_row = Adw.ActionRow()
        action_row.set_title("Sequence Playback")
        action_row.set_subtitle("Run step-by-step automation")
        
        tbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        tbox.set_valign(Gtk.Align.CENTER)
        
        self.btn_play = Gtk.Button(label="▶ Run Sequence")
        self.btn_play.add_css_class("suggested-action")
        self.btn_play.connect("clicked", lambda b: self._start_sequence())
        
        self.btn_pause = Gtk.Button(label="⏸ Pause")
        self.btn_pause.connect("clicked", lambda b: self.backend.pause_sequence())
        
        self.btn_stop = Gtk.Button(label="⏹ Stop")
        self.btn_stop.add_css_class("destructive-action")
        self.btn_stop.connect("clicked", lambda b: self.backend.stop_sequence())
        
        self.chk_loop = Gtk.CheckButton(label="🔁 Loop Forever")
        self.chk_loop.set_active(True)
        
        tbox.append(self.btn_play)
        tbox.append(self.btn_pause)
        tbox.append(self.btn_stop)
        tbox.append(self.chk_loop)
        action_row.add_suffix(tbox)
        ctrl_group.add(action_row)
        
        # Presets Row
        preset_row = Adw.ActionRow()
        preset_row.set_title("Load Preset Recipe")
        preset_row.set_subtitle("Select a pre-configured automation script")
        
        self.combo_presets = Gtk.DropDown.new_from_strings(list(PRESET_SEQUENCES.keys()))
        self.combo_presets.set_valign(Gtk.Align.CENTER)
        self.combo_presets.connect("notify::selected", self._on_preset_selected)
        preset_row.add_suffix(self.combo_presets)
        ctrl_group.add(preset_row)
        
        self.append(ctrl_group)
        
        # Sequence Steps Card
        steps_group = Adw.PreferencesGroup()
        steps_group.set_title("Sequence Steps")
        steps_group.set_description("List of operations executed in order.")
        
        # Add Step &amp; Clear Buttons Row
        tools_row = Adw.ActionRow()
        tools_row.set_title("Step Management")
        
        sbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        sbox.set_valign(Gtk.Align.CENTER)
        
        btn_add_step = Gtk.Button(label="➕ Add Step")
        btn_add_step.connect("clicked", lambda b: self._show_add_step_dialog())
        
        btn_clear = Gtk.Button(label="🗑 Clear All")
        btn_clear.connect("clicked", lambda b: self._clear_steps())
        
        sbox.append(btn_add_step)
        sbox.append(btn_clear)
        tools_row.add_suffix(sbox)
        steps_group.add(tools_row)
        
        # Scrolled List Box for Steps
        scroll = Gtk.ScrolledWindow()
        scroll.set_min_content_height(260)
        scroll.set_vexpand(True)
        
        self.list_box = Gtk.ListBox()
        self.list_box.set_selection_mode(Gtk.SelectionMode.NONE)
        self.list_box.add_css_class("boxed-list")
        scroll.set_child(self.list_box)
        
        steps_group.add(scroll)
        self.append(steps_group)

    def _on_preset_selected(self, dropdown, param):
        key = list(PRESET_SEQUENCES.keys())[dropdown.get_selected()]
        self.steps = list(PRESET_SEQUENCES[key])
        self._refresh_step_list()

    def _refresh_step_list(self):
        # Remove old rows
        while True:
            row = self.list_box.get_row_at_index(0)
            if not row:
                break
            self.list_box.remove(row)
            
        self.step_rows.clear()
        
        for idx, step in enumerate(self.steps):
            row = Adw.ActionRow()
            act = step.get('action')
            pin = step.get('pin', 'LED')
            delay = step.get('delay_ms', 100)
            desc = step.get('desc', '')
            
            title = f"Step {idx + 1}: [{act}] Pin {pin}"
            if act == 'WRITE':
                title += f" -> {'HIGH (3.3V)' if step.get('val') else 'LOW (0V)'}"
            elif act == 'PWM':
                title += f" -> {step.get('freq', 1000)}Hz, {step.get('duty', 50)}%"
            elif act == 'SERVO':
                title += f" -> {step.get('angle', 90)}°"
            elif act == 'LED':
                title = f"Step {idx + 1}: [LED] -> {'ON' if step.get('val') else 'OFF'}"
                
            row.set_title(title)
            row.set_subtitle(f"Delay: {delay}ms | {desc}")
            
            # Delete button for step
            del_btn = Gtk.Button(icon_name="user-trash-symbolic")
            del_btn.set_valign(Gtk.Align.CENTER)
            del_btn.connect("clicked", lambda b, i=idx: self._delete_step(i))
            row.add_suffix(del_btn)
            
            self.list_box.append(row)
            self.step_rows.append(row)

    def _delete_step(self, idx):
        if 0 <= idx < len(self.steps):
            self.steps.pop(idx)
            self._refresh_step_list()

    def _clear_steps(self):
        self.steps.clear()
        self._refresh_step_list()

    def _start_sequence(self):
        if not self.steps:
            return
        loop = self.chk_loop.get_active()
        self.backend.start_sequence(self.steps, loop=loop)

    def highlight_step(self, step_idx):
        for i, row in enumerate(self.step_rows):
            if i == step_idx:
                row.add_css_class("accent")
            else:
                row.remove_css_class("accent")

    def _show_add_step_dialog(self):
        # Quick append digital toggle step
        new_step = {'action': 'TOGGLE', 'pin': 15, 'delay_ms': 200, 'desc': 'Toggle GP15'}
        self.steps.append(new_step)
        self._refresh_step_list()
