"""
Cairo-Rendered PWM Square Waveform Visualizer Widget
"""

import gi
gi.require_version('Gtk', '4.0')
from gi.repository import Gtk
import cairo


class PWMWaveformVisualizer(Gtk.DrawingArea):
    """Dynamic square waveform visualization for hardware PWM."""
    
    def __init__(self):
        super().__init__()
        self.set_hexpand(True)
        self.set_size_request(300, 100)
        self.freq_hz = 1000
        self.duty_percent = 50.0
        self.is_active = True
        
        self.set_draw_func(self._draw_wave)

    def update_params(self, freq_hz, duty_percent, active=True):
        self.freq_hz = max(1, int(freq_hz))
        self.duty_percent = max(0.0, min(100.0, float(duty_percent)))
        self.is_active = active
        self.queue_draw()

    def _draw_wave(self, area, cr, width, height):
        # Background
        cr.set_source_rgb(0.08, 0.10, 0.13)
        cr.rectangle(0, 0, width, height)
        cr.fill()
        
        # Border
        cr.set_source_rgb(0.18, 0.22, 0.28)
        cr.set_line_width(1.0)
        cr.rectangle(1, 1, width - 2, height - 2)
        cr.stroke()
        
        if not self.is_active or self.duty_percent <= 0.0:
            # Flat 0V line
            cr.set_source_rgb(0.5, 0.5, 0.5)
            cr.set_line_width(2.0)
            cr.move_to(10, height - 20)
            cr.line_to(width - 10, height - 20)
            cr.stroke()
            
            cr.set_source_rgb(0.6, 0.6, 0.6)
            cr.select_font_face("Monospace", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
            cr.set_font_size(10)
            cr.move_to(width / 2.0 - 45, height / 2.0)
            cr.show_text("PWM INACTIVE (0V)")
            return

        if self.duty_percent >= 100.0:
            # Flat 3.3V line
            cr.set_source_rgb(0.96, 0.65, 0.14)
            cr.set_line_width(2.0)
            cr.move_to(10, 25)
            cr.line_to(width - 10, 25)
            cr.stroke()
            return

        # Draw 4 full cycles of square wave
        cycles = 4
        margin_x = 15
        wave_w = width - 2 * margin_x
        cycle_w = wave_w / cycles
        
        high_y = 25
        low_y = height - 20
        high_w = cycle_w * (self.duty_percent / 100.0)
        low_w = cycle_w - high_w
        
        cr.set_source_rgb(0.96, 0.65, 0.14)  # Amber PWM glow
        cr.set_line_width(2.5)
        
        cur_x = margin_x
        cr.move_to(cur_x, low_y)
        
        for _ in range(cycles):
            # Rising edge
            cr.line_to(cur_x, high_y)
            # High state
            cur_x += high_w
            cr.line_to(cur_x, high_y)
            # Falling edge
            cr.line_to(cur_x, low_y)
            # Low state
            cur_x += low_w
            cr.line_to(cur_x, low_y)
            
        cr.stroke()
        
        # Overlay labels
        cr.set_source_rgb(0.85, 0.85, 0.85)
        cr.select_font_face("Monospace", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(9)
        cr.move_to(margin_x + 5, 16)
        cr.show_text(f"FREQ: {self.freq_hz} Hz  |  DUTY: {self.duty_percent:.1f}% ({int(self.duty_percent*655.35)} / 65535)")
