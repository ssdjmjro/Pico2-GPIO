#!/usr/bin/env python3
"""
Pico GPIO Studio Application Entry Point
"""

import os
import sys

# Ensure root package is in sys.path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, Gdk, Gio

from gui.window import PicoStudioWindow


class PicoStudioApplication(Adw.Application):
    def __init__(self):
        super().__init__(
            application_id="io.github.pico.gpio.studio",
            flags=Gio.ApplicationFlags.FLAGS_NONE
        )

    def do_activate(self):
        win = self.get_active_window()
        if not win:
            self._load_css()
            win = PicoStudioWindow(application=self)
        win.present()

    def _load_css(self):
        css_file = os.path.join(os.path.dirname(__file__), "style.css")
        if os.path.exists(css_file):
            provider = Gtk.CssProvider()
            provider.load_from_path(css_file)
            Gtk.StyleContext.add_provider_for_display(
                Gdk.Display.get_default(),
                provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )


def main():
    app = PicoStudioApplication()
    return app.run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
