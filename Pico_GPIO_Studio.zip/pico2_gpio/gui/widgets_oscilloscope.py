"""
Cairo-Rendered Real-Time ADC Oscilloscope / Voltmeter Graph
"""

import math
import time
import gi
gi.require_version('Gtk', '4.0')
from gi.repository import Gtk, Gdk
import cairo


class ADCOscilloscope(Gtk.DrawingArea):
    """Real-time rolling voltage oscilloscope for GP26, GP27, GP28."""
    
    def __init__(self):
        super().__init__()
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.set_size_request(400, 220)
        
        self.samples = []  # [(timestamp, voltage)]
        self.current_volts = 0.0
        self.current_raw = 0
        self.min_v = 0.0
        self.max_v = 0.0
        self.pin_name = "GP26 (ADC0)"
        
        self.set_draw_func(self._draw_scope)

    def add_sample(self, volts, raw=0, pin_name="GP26"):
        self.current_volts = float(volts)
        self.current_raw = int(raw)
        self.pin_name = pin_name
        self.samples.append((time.time(), self.current_volts))
        if len(self.samples) > 200:
            self.samples.pop(0)
            
        voltages = [s[1] for s in self.samples]
        self.min_v = min(voltages) if voltages else 0.0
        self.max_v = max(voltages) if voltages else 0.0
        self.queue_draw()

    def clear(self):
        self.samples.clear()
        self.queue_draw()

    def _draw_scope(self, area, cr, width, height):
        # 1. Dark CRT / Oscilloscope Background
        cr.save()
        cr.set_source_rgb(0.06, 0.08, 0.11)
        cr.rectangle(0, 0, width, height)
        cr.fill()
        
        # Rounded border
        cr.set_source_rgb(0.18, 0.22, 0.28)
        cr.set_line_width(1.5)
        cr.rectangle(1, 1, width - 2, height - 2)
        cr.stroke()
        
        margin_l = 45
        margin_r = 15
        margin_t = 30
        margin_b = 25
        plot_w = width - margin_l - margin_r
        plot_h = height - margin_t - margin_b
        
        # 2. Draw Grid Lines (0V, 1V, 2V, 3V, 3.3V)
        cr.set_line_width(0.7)
        cr.set_dash([4.0, 4.0])
        cr.select_font_face("Monospace", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        cr.set_font_size(9)
        
        v_steps = [0.0, 1.0, 2.0, 3.0, 3.3]
        for v in v_steps:
            gy = margin_t + plot_h - (v / 3.3) * plot_h
            # Grid line
            cr.set_source_rgba(0.25, 0.35, 0.45, 0.4)
            cr.move_to(margin_l, gy)
            cr.line_to(margin_l + plot_w, gy)
            cr.stroke()
            
            # Voltage Label
            cr.set_source_rgba(0.6, 0.7, 0.8, 0.8)
            cr.move_to(8, gy + 3)
            cr.show_text(f"{v:.1f}V")

        cr.set_dash([])  # restore solid lines
        
        # 3. Draw Vertical time grid
        for i in range(5):
            gx = margin_l + i * (plot_w / 4.0)
            cr.set_source_rgba(0.25, 0.35, 0.45, 0.25)
            cr.move_to(gx, margin_t)
            cr.line_to(gx, margin_t + plot_h)
            cr.stroke()

        # 4. Draw Oscilloscope Trace Line
        if len(self.samples) >= 2:
            cr.set_line_width(2.2)
            cr.set_source_rgb(0.2, 0.85, 1.0)  # Cyan Phosphor Glow
            
            first = True
            n = len(self.samples)
            for idx, (_, v) in enumerate(self.samples):
                clamped_v = max(0.0, min(3.3, v))
                x = margin_l + (idx / (n - 1)) * plot_w
                y = margin_t + plot_h - (clamped_v / 3.3) * plot_h
                if first:
                    cr.move_to(x, y)
                    first = False
                else:
                    cr.line_to(x, y)
            cr.stroke()
            
            # Head Glow Point
            last_idx = n - 1
            last_v = max(0.0, min(3.3, self.samples[-1][1]))
            hx = margin_l + plot_w
            hy = margin_t + plot_h - (last_v / 3.3) * plot_h
            
            cr.arc(hx, hy, 5, 0, 2 * math.pi)
            cr.set_source_rgb(0.4, 0.95, 1.0)
            cr.fill_preserve()
            cr.set_source_rgba(0.2, 0.8, 1.0, 0.5)
            cr.set_line_width(4)
            cr.stroke()

        # 5. Header Overlay (Channel info & stats)
        cr.select_font_face("Monospace", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(11)
        cr.set_source_rgb(0.2, 0.85, 1.0)
        cr.move_to(margin_l, 18)
        cr.show_text(f"CH1: {self.pin_name}")
        
        # Real-time measurements badge
        cr.set_source_rgb(0.95, 0.95, 0.95)
        cr.move_to(width - 190, 18)
        cr.show_text(f"NOW: {self.current_volts:.3f}V ({self.current_raw})")
        
        cr.set_font_size(9)
        cr.set_source_rgb(0.65, 0.75, 0.85)
        cr.move_to(margin_l, height - 8)
        cr.show_text(f"MIN: {self.min_v:.3f}V  |  MAX: {self.max_v:.3f}V  |  Vpp: {abs(self.max_v - self.min_v):.3f}V")
        
        cr.restore()
