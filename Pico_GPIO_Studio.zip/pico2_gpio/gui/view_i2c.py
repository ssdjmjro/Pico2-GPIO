"""
Pico I2C Bus Scanner View
Visual 16x8 hex grid and peripheral device detection.
"""

import threading
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib

from .pinout_data import KNOWN_I2C_DEVICES


class I2CScannerView(Gtk.Box):
    def __init__(self, backend):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.backend = backend
        self.set_margin_top(12)
        self.set_margin_bottom(12)
        self.set_margin_start(16)
        self.set_margin_end(16)
        
        self.cell_widgets = {}  # addr_int -> Gtk.Label
        self.found_devices = []
        
        self._build_ui()

    def _build_ui(self):
        group = Adw.PreferencesGroup()
        group.set_title("I2C Peripheral Bus Scanner")
        group.set_description("Scan 7-bit I2C addresses (0x08 to 0x77) to discover attached sensors, displays, and NFC modules.")
        
        # Pin Configuration Row
        cfg_row = Adw.ActionRow()
        cfg_row.set_title("I2C Pin Selection")
        cfg_row.set_subtitle("Default: SDA = GP4 (Pin 6), SCL = GP5 (Pin 7)")
        
        pbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        pbox.set_valign(Gtk.Align.CENTER)
        
        lbl_sda = Gtk.Label(label="SDA GP:")
        self.spin_sda = Gtk.SpinButton.new_with_range(0, 28, 1)
        self.spin_sda.set_value(4)
        
        lbl_scl = Gtk.Label(label="SCL GP:")
        self.spin_scl = Gtk.SpinButton.new_with_range(0, 28, 1)
        self.spin_scl.set_value(5)
        
        self.btn_scan = Gtk.Button(label="🔍 Scan Bus Now")
        self.btn_scan.add_css_class("suggested-action")
        self.btn_scan.connect("clicked", lambda b: self._start_scan())
        
        pbox.append(lbl_sda)
        pbox.append(self.spin_sda)
        pbox.append(lbl_scl)
        pbox.append(self.spin_scl)
        pbox.append(self.btn_scan)
        cfg_row.add_suffix(pbox)
        group.add(cfg_row)
        
        # Discovered Devices Summary Row
        self.row_results = Adw.ActionRow()
        self.row_results.set_title("Scan Status")
        self.row_results.set_subtitle("Ready to scan I2C bus")
        group.add(self.row_results)
        
        self.append(group)
        
        # 16x8 Hex Matrix
        grid_group = Adw.PreferencesGroup()
        grid_group.set_title("7-Bit I2C Address Matrix (0x00 - 0x7F)")
        
        grid_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        grid_box.add_css_class("pico-card-box")
        
        # Header row (0x00 to 0x0F)
        h_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        corner_lbl = Gtk.Label(label="   ")
        corner_lbl.add_css_class("pico-hex-cell")
        h_box.append(corner_lbl)
        for col in range(16):
            col_lbl = Gtk.Label(label=f"{col:X}")
            col_lbl.add_css_class("pico-hex-cell")
            h_box.append(col_lbl)
        grid_box.append(h_box)
        
        # 8 Rows (0x0_ to 0x7_)
        for row in range(8):
            r_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
            row_prefix = Gtk.Label(label=f"0x{row:X}_")
            row_prefix.add_css_class("pico-hex-cell")
            r_box.append(row_prefix)
            
            for col in range(16):
                addr = (row << 4) | col
                if addr < 0x08 or addr > 0x77:
                    cell_lbl = Gtk.Label(label="--")
                    cell_lbl.set_opacity(0.3)
                else:
                    cell_lbl = Gtk.Label(label=f"{addr:02X}")
                    self.cell_widgets[addr] = cell_lbl
                cell_lbl.add_css_class("pico-hex-cell")
                r_box.append(cell_lbl)
                
            grid_box.append(r_box)
            
        grid_group.add(grid_box)
        self.append(grid_group)
        
        # Discovered Sensor Details Card
        self.dev_group = Adw.PreferencesGroup()
        self.dev_group.set_title("Detected Peripherals &amp; Common Chips")
        self.append(self.dev_group)

    def _start_scan(self):
        self.btn_scan.set_sensitive(False)
        self.row_results.set_title("Scanning I2C bus...")
        self.row_results.set_subtitle("Querying 112 potential addresses...")
        
        # Reset grid highlights
        for addr, lbl in self.cell_widgets.items():
            lbl.remove_css_class("pico-hex-found")
            lbl.set_text(f"{addr:02X}")
            
        sda = int(self.spin_sda.get_value())
        scl = int(self.spin_scl.get_value())
        
        threading.Thread(target=self._scan_thread, args=(sda, scl), daemon=True).start()

    def _scan_thread(self, sda, scl):
        devs = self.backend.scan_i2c(sda, scl, 0)
        GLib.idle_add(self._on_scan_complete, devs)

    def _on_scan_complete(self, devs):
        self.btn_scan.set_sensitive(True)
        self.found_devices = devs
        
        # Clear old device rows
        # Remove children from dev_group
        # (In GTK4 Adw.PreferencesGroup, we can manage rows or re-create)
        
        if not devs:
            self.row_results.set_title("No I2C Devices Detected")
            self.row_results.set_subtitle("Check wiring: VCC -> 3V3, GND -> GND, SDA -> GP4, SCL -> GP5")
        else:
            self.row_results.set_title(f"Found {len(devs)} I2C Device(s)!")
            self.row_results.set_subtitle(f"Addresses: {', '.join(devs)}")
            
            for d in devs:
                try:
                    addr_int = int(d, 16) if str(d).startswith("0x") else int(d)
                    if addr_int in self.cell_widgets:
                        lbl = self.cell_widgets[addr_int]
                        lbl.add_css_class("pico-hex-found")
                        lbl.set_text(f"{addr_int:02X}★")
                except Exception:
                    pass
