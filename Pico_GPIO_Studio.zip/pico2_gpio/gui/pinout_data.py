"""
Raspberry Pi Pico / Pico 2 Pinout and Hardware Capabilities Data
"""

# Pin layout definition for the 40 DIP pins
# type: 'gp', 'gnd', 'pwr', 'adc', 'ctrl'
PICO_PINS = {
    1:  {'num': 1,  'gp': 0,    'name': 'GP0',     'type': 'gp',  'alt': 'UART0 TX, I2C0 SDA, PWM0 A', 'side': 'left',  'index': 0},
    2:  {'num': 2,  'gp': 1,    'name': 'GP1',     'type': 'gp',  'alt': 'UART0 RX, I2C0 SCL, PWM0 B', 'side': 'left',  'index': 1},
    3:  {'num': 3,  'gp': None, 'name': 'GND',     'type': 'gnd', 'alt': 'Ground',                     'side': 'left',  'index': 2},
    4:  {'num': 4,  'gp': 2,    'name': 'GP2',     'type': 'gp',  'alt': 'SPI0 SCK, I2C1 SDA, PWM1 A', 'side': 'left',  'index': 3},
    5:  {'num': 5,  'gp': 3,    'name': 'GP3',     'type': 'gp',  'alt': 'SPI0 TX, I2C1 SCL, PWM1 B',  'side': 'left',  'index': 4},
    6:  {'num': 6,  'gp': 4,    'name': 'GP4',     'type': 'gp',  'alt': 'SPI0 RX, I2C0 SDA, PWM2 A',  'side': 'left',  'index': 5},
    7:  {'num': 7,  'gp': 5,    'name': 'GP5',     'type': 'gp',  'alt': 'SPI0 CSn, I2C0 SCL, PWM2 B', 'side': 'left',  'index': 6},
    8:  {'num': 8,  'gp': None, 'name': 'GND',     'type': 'gnd', 'alt': 'Ground',                     'side': 'left',  'index': 7},
    9:  {'num': 9,  'gp': 6,    'name': 'GP6',     'type': 'gp',  'alt': 'I2C1 SDA, PWM3 A',           'side': 'left',  'index': 8},
    10: {'num': 10, 'gp': 7,    'name': 'GP7',     'type': 'gp',  'alt': 'I2C1 SCL, PWM3 B',           'side': 'left',  'index': 9},
    11: {'num': 11, 'gp': 8,    'name': 'GP8',     'type': 'gp',  'alt': 'UART1 TX, I2C0 SDA, PWM4 A', 'side': 'left',  'index': 10},
    12: {'num': 12, 'gp': 9,    'name': 'GP9',     'type': 'gp',  'alt': 'UART1 RX, I2C0 SCL, PWM4 B', 'side': 'left',  'index': 11},
    13: {'num': 13, 'gp': None, 'name': 'GND',     'type': 'gnd', 'alt': 'Ground',                     'side': 'left',  'index': 12},
    14: {'num': 14, 'gp': 10,   'name': 'GP10',    'type': 'gp',  'alt': 'SPI1 SCK, I2C1 SDA, PWM5 A', 'side': 'left',  'index': 13},
    15: {'num': 15, 'gp': 11,   'name': 'GP11',    'type': 'gp',  'alt': 'SPI1 TX, I2C1 SCL, PWM5 B',  'side': 'left',  'index': 14},
    16: {'num': 16, 'gp': 12,   'name': 'GP12',    'type': 'gp',  'alt': 'SPI1 RX, I2C0 SDA, PWM6 A',  'side': 'left',  'index': 15},
    17: {'num': 17, 'gp': 13,   'name': 'GP13',    'type': 'gp',  'alt': 'SPI1 CSn, I2C0 SCL, PWM6 B', 'side': 'left',  'index': 16},
    18: {'num': 18, 'gp': None, 'name': 'GND',     'type': 'gnd', 'alt': 'Ground',                     'side': 'left',  'index': 17},
    19: {'num': 19, 'gp': 14,   'name': 'GP14',    'type': 'gp',  'alt': 'I2C1 SDA, PWM7 A',           'side': 'left',  'index': 18},
    20: {'num': 20, 'gp': 15,   'name': 'GP15',    'type': 'gp',  'alt': 'I2C1 SCL, PWM7 B',           'side': 'left',  'index': 19},

    21: {'num': 21, 'gp': 16,   'name': 'GP16',    'type': 'gp',  'alt': 'SPI0 RX, I2C0 SDA, PWM0 A',  'side': 'right', 'index': 19},
    22: {'num': 22, 'gp': 17,   'name': 'GP17',    'type': 'gp',  'alt': 'SPI0 CSn, I2C0 SCL, PWM0 B', 'side': 'right', 'index': 18},
    23: {'num': 23, 'gp': None, 'name': 'GND',     'type': 'gnd', 'alt': 'Ground',                     'side': 'right', 'index': 17},
    24: {'num': 24, 'gp': 18,   'name': 'GP18',    'type': 'gp',  'alt': 'SPI0 SCK, I2C1 SDA, PWM1 A', 'side': 'right', 'index': 16},
    25: {'num': 25, 'gp': 19,   'name': 'GP19',    'type': 'gp',  'alt': 'SPI0 TX, I2C1 SCL, PWM1 B',  'side': 'right', 'index': 15},
    26: {'num': 26, 'gp': 20,   'name': 'GP20',    'type': 'gp',  'alt': 'I2C0 SDA, PWM2 A',           'side': 'right', 'index': 14},
    27: {'num': 27, 'gp': 21,   'name': 'GP21',    'type': 'gp',  'alt': 'I2C0 SCL, PWM2 B',           'side': 'right', 'index': 13},
    28: {'num': 28, 'gp': None, 'name': 'GND',     'type': 'gnd', 'alt': 'Ground',                     'side': 'right', 'index': 12},
    29: {'num': 29, 'gp': 22,   'name': 'GP22',    'type': 'gp',  'alt': 'PWM3 A',                     'side': 'right', 'index': 11},
    30: {'num': 30, 'gp': None, 'name': 'RUN',     'type': 'ctrl', 'alt': 'Reset Enable Pin',           'side': 'right', 'index': 10},
    31: {'num': 31, 'gp': 26,   'name': 'GP26',    'type': 'adc', 'alt': 'ADC0 (0-3.3V), I2C1 SDA',     'side': 'right', 'index': 9},
    32: {'num': 32, 'gp': 27,   'name': 'GP27',    'type': 'adc', 'alt': 'ADC1 (0-3.3V), I2C1 SCL',     'side': 'right', 'index': 8},
    33: {'num': 33, 'gp': None, 'name': 'AGND',    'type': 'gnd', 'alt': 'Analog Ground Reference',     'side': 'right', 'index': 7},
    34: {'num': 34, 'gp': 28,   'name': 'GP28',    'type': 'adc', 'alt': 'ADC2 (0-3.3V), PWM6 A',       'side': 'right', 'index': 6},
    35: {'num': 35, 'gp': None, 'name': 'ADC_VREF','type': 'pwr', 'alt': 'ADC Reference Voltage (3.3V)', 'side': 'right', 'index': 5},
    36: {'num': 36, 'gp': None, 'name': '3V3',     'type': 'pwr', 'alt': '3.3V System Power Output',    'side': 'right', 'index': 4},
    37: {'num': 37, 'gp': None, 'name': '3V3_EN',  'type': 'ctrl', 'alt': 'Regulator Enable Pin',        'side': 'right', 'index': 3},
    38: {'num': 38, 'gp': None, 'name': 'GND',     'type': 'gnd', 'alt': 'Ground',                     'side': 'right', 'index': 2},
    39: {'num': 39, 'gp': None, 'name': 'VSYS',    'type': 'pwr', 'alt': 'System Input Power (1.8-5.5V)','side': 'right', 'index': 1},
    40: {'num': 40, 'gp': None, 'name': 'VBUS',    'type': 'pwr', 'alt': 'Micro-USB 5V Power Input',   'side': 'right', 'index': 0},
}

# Lookup map from GP pin number to physical pin info
GP_TO_PIN = {v['gp']: v for v in PICO_PINS.values() if v['gp'] is not None}

ADC_PINS = [26, 27, 28]

KNOWN_I2C_DEVICES = {
    0x24: "PN532 NFC / RFID Module",
    0x27: "PCF8574 LCD 1602/2004 Backpack",
    0x36: "MAX17043 LiPo Fuel Gauge / PN532",
    0x38: "AHT10 / AHT20 Temp & Humidity",
    0x3C: "SSD1306 / SH1106 OLED 128x64 / 128x32",
    0x3D: "SSD1306 OLED (Alt Address)",
    0x3F: "PCF8574A LCD Backpack",
    0x48: "ADS1115 16-Bit ADC / TMP102 Temp",
    0x49: "ADS1115 (Alt Address)",
    0x50: "AT24C32 / 24Cxx EEPROM",
    0x57: "MAX30102 / MAX30100 Pulse Oximeter",
    0x68: "MPU6050 / DS3231 RTC / ICM20948 IMU",
    0x69: "MPU6050 (Alt Address) / ICM20948",
    0x76: "BMP280 / BME280 / BME680 Environmental",
    0x77: "BMP280 / BME280 / BMP180 (Alt Address)",
}
