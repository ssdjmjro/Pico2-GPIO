"""
Pico GPIO Backend Service
Thread-safe controller with asynchronous polling, sequencing, and telemetry.
"""

import time
import threading
import queue
from gi.repository import GLib

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pico_gpio import PicoGPIO, PicoGPIOError, IN, OUT, IN_PULLUP, IN_PULLDOWN, HIGH, LOW


class BackendEvent:
    def __init__(self, event_type, data=None):
        self.event_type = event_type
        self.data = data or {}


class PicoBackend:
    """Manages serial communication and state polling safely in the background."""
    
    def __init__(self, on_event=None):
        self.pico = None
        self.on_event_cb = on_event
        self.is_connected = False
        self.port_name = "Not Connected"
        self.is_mock = False
        
        # Telemetry cache
        self.last_temp = 25.0
        self.active_pins = {}
        self.pwm_pins = {}
        self.pin_values = {}
        self.adc_history = {26: [], 27: [], 28: []}
        self.polling_active = False
        self.poll_thread = None
        self.poll_lock = threading.Lock()
        
        # Active monitor config
        self.monitored_adc_pins = set()
        self.monitored_digital_pins = set()
        self.poll_interval = 0.1  # 100ms default
        
        # Sequence Automation Runner
        self.seq_running = False
        self.seq_paused = False
        self.seq_thread = None
        self.seq_stop_event = threading.Event()
        self.seq_pause_event = threading.Event()
        self.seq_pause_event.set()
        
        # Command logging callback
        self.log_history = []

    def dispatch_ui_event(self, event_type, **kwargs):
        """Dispatch event safely to GTK main loop."""
        if self.on_event_cb:
            GLib.idle_add(self.on_event_cb, BackendEvent(event_type, kwargs))

    def _log_handler(self, cmd, resp, is_err):
        entry = {
            'time': time.strftime("%H:%M:%S") + f".{int(time.time()*1000)%1000:03d}",
            'cmd': cmd,
            'resp': resp,
            'is_err': is_err
        }
        self.log_history.append(entry)
        if len(self.log_history) > 300:
            self.log_history.pop(0)
        self.dispatch_ui_event('console_log', entry=entry)

    def connect(self, port=None, mock=False):
        """Connect to Pico hardware or start mock simulation."""
        self.disconnect()
        try:
            self.is_mock = mock
            self.pico = PicoGPIO(port=port, mock=mock, log_callback=self._log_handler)
            self.is_connected = True
            self.port_name = self.pico.port
            
            # Start background state poller
            self.polling_active = True
            self.poll_thread = threading.Thread(target=self._poll_worker, daemon=True)
            self.poll_thread.start()
            
            self.dispatch_ui_event('connected', port=self.port_name, mock=self.is_mock)
            return True, f"Connected to {self.port_name}"
        except Exception as e:
            self.is_connected = False
            self.dispatch_ui_event('connection_error', error=str(e))
            return False, str(e)

    def disconnect(self):
        """Disconnect and stop background polling."""
        self.polling_active = False
        self.stop_sequence()
        if self.pico:
            try:
                self.pico.close()
            except Exception:
                pass
            self.pico = None
        self.is_connected = False
        self.port_name = "Not Connected"
        self.dispatch_ui_event('disconnected')

    def _poll_worker(self):
        """Background loop for reading ADC, inputs, and core temperature."""
        counter = 0
        while self.polling_active and self.pico:
            try:
                if not self.pico.is_connected():
                    break
                
                # Periodically read telemetry (every ~1s)
                counter += 1
                if counter % 10 == 0:
                    try:
                        temp = self.pico.get_internal_temp()
                        self.last_temp = temp
                        self.dispatch_ui_event('telemetry_temp', temp=temp)
                    except Exception:
                        pass

                # Read active monitored digital pins
                with self.poll_lock:
                    dig_pins = list(self.monitored_digital_pins)
                    adc_pins = list(self.monitored_adc_pins)
                
                for pin in dig_pins:
                    if not self.polling_active or not self.pico:
                        break
                    try:
                        v = self.pico.digital_read(pin)
                        self.pin_values[pin] = v
                        self.dispatch_ui_event('pin_digital_val', pin=pin, val=v)
                    except Exception:
                        pass
                
                for adc_pin in adc_pins:
                    if not self.polling_active or not self.pico:
                        break
                    try:
                        data = self.pico.analog_read_full(adc_pin)
                        val = data['volts']
                        raw = data['raw']
                        hist = self.adc_history.setdefault(adc_pin, [])
                        hist.append((time.time(), val))
                        if len(hist) > 150:
                            hist.pop(0)
                        self.dispatch_ui_event('adc_voltage', pin=adc_pin, volts=val, raw=raw, history=hist)
                    except Exception:
                        pass

            except Exception:
                pass

            time.sleep(self.poll_interval)

    # ------------------ High Level Hardware Actions ------------------ #

    def set_pin_mode(self, pin, mode):
        if not self.pico:
            return False, "Not connected"
        try:
            resp = self.pico.pin_mode(pin, mode)
            self.dispatch_ui_event('pin_mode_changed', pin=pin, mode=mode)
            return True, resp
        except Exception as e:
            return False, str(e)

    def write_pin(self, pin, val):
        if not self.pico:
            return False, "Not connected"
        try:
            resp = self.pico.digital_write(pin, val)
            self.pin_values[pin] = 1 if val else 0
            self.dispatch_ui_event('pin_digital_val', pin=pin, val=self.pin_values[pin])
            return True, resp
        except Exception as e:
            return False, str(e)

    def toggle_pin(self, pin):
        if not self.pico:
            return False, "Not connected"
        try:
            val = self.pico.toggle(pin)
            self.pin_values[pin] = val
            self.dispatch_ui_event('pin_digital_val', pin=pin, val=val)
            return True, val
        except Exception as e:
            return False, str(e)

    def set_led(self, state):
        if not self.pico:
            return False, "Not connected"
        try:
            resp = self.pico.led(state)
            self.dispatch_ui_event('led_state_changed', state=self.pico.led_state)
            return True, resp
        except Exception as e:
            return False, str(e)

    def read_pin(self, pin):
        if not self.pico:
            return 0
        try:
            val = self.pico.digital_read(pin)
            self.pin_values[pin] = val
            self.dispatch_ui_event('pin_digital_val', pin=pin, val=val)
            return val
        except Exception:
            return 0

    def read_adc(self, pin):
        if not self.pico:
            return {'raw': 0, 'volts': 0.0}
        try:
            return self.pico.analog_read_full(pin)
        except Exception:
            return {'raw': 0, 'volts': 0.0}

    def set_pwm(self, pin, freq, duty):
        if not self.pico:
            return False, "Not connected"
        try:
            resp = self.pico.pwm(pin, freq=freq, duty=duty)
            self.dispatch_ui_event('pwm_changed', pin=pin, freq=freq, duty=duty)
            return True, resp
        except Exception as e:
            return False, str(e)

    def stop_pwm(self, pin):
        if not self.pico:
            return False, "Not connected"
        try:
            resp = self.pico.pwm_stop(pin)
            self.dispatch_ui_event('pwm_stopped', pin=pin)
            return True, resp
        except Exception as e:
            return False, str(e)

    def set_servo(self, pin, angle):
        if not self.pico:
            return False, "Not connected"
        try:
            resp = self.pico.servo(pin, angle)
            self.dispatch_ui_event('servo_changed', pin=pin, angle=angle)
            return True, resp
        except Exception as e:
            return False, str(e)

    def scan_i2c(self, sda=4, scl=5, bus=0):
        if not self.pico:
            return []
        try:
            return self.pico.i2c_scan(sda, scl, bus)
        except Exception:
            return []

    def emergency_all_off(self):
        """Emergency safe stop."""
        if not self.pico:
            return
        try:
            self.pico.all_off()
            self.dispatch_ui_event('all_off')
        except Exception:
            pass

    def send_raw(self, cmd_str):
        if not self.pico:
            return "ERR: Not connected"
        try:
            return self.pico.send_command(cmd_str)
        except Exception as e:
            return f"ERR: {e}"

    # ------------------ Sequence Automation Engine ------------------ #

    def start_sequence(self, steps, loop=False):
        """Run automation sequence in background thread."""
        if self.seq_running:
            self.stop_sequence()
        
        self.seq_running = True
        self.seq_stop_event.clear()
        self.seq_pause_event.set()
        self.seq_thread = threading.Thread(target=self._sequence_worker, args=(steps, loop), daemon=True)
        self.seq_thread.start()
        self.dispatch_ui_event('seq_started')

    def pause_sequence(self):
        if self.seq_running:
            if self.seq_pause_event.is_set():
                self.seq_pause_event.clear()
                self.dispatch_ui_event('seq_paused')
            else:
                self.seq_pause_event.set()
                self.dispatch_ui_event('seq_resumed')

    def stop_sequence(self):
        if self.seq_running:
            self.seq_stop_event.set()
            self.seq_pause_event.set()
            self.seq_running = False
            self.dispatch_ui_event('seq_stopped')

    def _sequence_worker(self, steps, loop):
        while not self.seq_stop_event.is_set():
            for idx, step in enumerate(steps):
                if self.seq_stop_event.is_set():
                    break
                self.seq_pause_event.wait()
                
                self.dispatch_ui_event('seq_step_active', step_index=idx)
                action = step.get('action')
                pin = step.get('pin')
                val = step.get('val')
                delay_ms = step.get('delay_ms', 100)
                
                try:
                    if action == 'WRITE':
                        self.write_pin(pin, val)
                    elif action == 'TOGGLE':
                        self.toggle_pin(pin)
                    elif action == 'PWM':
                        self.set_pwm(pin, step.get('freq', 1000), step.get('duty', 50.0))
                    elif action == 'PWM_STOP':
                        self.stop_pwm(pin)
                    elif action == 'SERVO':
                        self.set_servo(pin, step.get('angle', 90))
                    elif action == 'LED':
                        self.set_led(val)
                    elif action == 'ADC_READ':
                        self.read_adc(pin)
                    elif action == 'DELAY':
                        pass  # handled below
                except Exception:
                    pass
                
                # Sleep in small slices so stop is instant
                slices = int(max(1, delay_ms / 20))
                for _ in range(slices):
                    if self.seq_stop_event.is_set():
                        break
                    time.sleep(delay_ms / 1000.0 / slices)
                    
            if not loop or self.seq_stop_event.is_set():
                break
                
        self.seq_running = False
        self.dispatch_ui_event('seq_stopped')
