"""
Interactive Cairo-Rendered Pico 2 DIP-40 Board Widget
"""

import math
import gi
gi.require_version('Gtk', '4.0')
from gi.repository import Gtk, Gdk, GLib
import cairo

from .pinout_data import PICO_PINS, GP_TO_PIN


class PicoBoardCanvas(Gtk.DrawingArea):
    """Interactive visual representation of the Raspberry Pi Pico 2 board."""
    
    def __init__(self, on_pin_selected=None):
        super().__init__()
        self.on_pin_selected = on_pin_selected
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.set_size_request(620, 680)
        
        # State tracking
        self.hovered_pin = None
        self.selected_pin = 15  # GP15 default
        self.led_on = False
        self.temp_c = 25.0
        self.pin_states = {}  # gp -> {'mode': 'OUT', 'val': 0, ...}
        
        self.set_draw_func(self._draw_board)
        
        # Hitboxes for mouse detection: pin_num -> (x, y, w, h, gp)
        self.pin_hitboxes = {}
        
        # Event Controllers
        motion = Gtk.EventControllerMotion()
        motion.connect("motion", self._on_mouse_motion)
        motion.connect("leave", self._on_mouse_leave)
        self.add_controller(motion)
        
        click = Gtk.GestureClick()
        click.connect("pressed", self._on_mouse_click)
        self.add_controller(click)

    def update_pin_state(self, gp, mode=None, val=None, freq=None, duty=None, angle=None):
        if gp is None:
            return
        st = self.pin_states.setdefault(gp, {})
        if mode is not None:
            st['mode'] = mode
        if val is not None:
            st['val'] = val
        if freq is not None:
            st['freq'] = freq
        if duty is not None:
            st['duty'] = duty
        if angle is not None:
            st['angle'] = angle
        self.queue_draw()

    def update_led(self, state):
        self.led_on = bool(state)
        self.queue_draw()

    def update_temp(self, temp):
        self.temp_c = float(temp)
        self.queue_draw()

    def set_selected_pin(self, gp):
        self.selected_pin = gp
        self.queue_draw()

    def _on_mouse_motion(self, controller, x, y):
        prev_hover = self.hovered_pin
        self.hovered_pin = None
        for pnum, (bx, by, bw, bh, gp, name) in self.pin_hitboxes.items():
            if bx <= x <= bx + bw and by <= y <= by + bh:
                self.hovered_pin = pnum
                break
        if prev_hover != self.hovered_pin:
            self.queue_draw()
            if self.hovered_pin:
                pinfo = PICO_PINS.get(self.hovered_pin, {})
                tooltip = f"Pin {self.hovered_pin}: {pinfo.get('name')} | {pinfo.get('alt')}"
                self.set_tooltip_text(tooltip)
            else:
                self.set_tooltip_text(None)

    def _on_mouse_leave(self, controller):
        if self.hovered_pin is not None:
            self.hovered_pin = None
            self.queue_draw()
            self.set_tooltip_text(None)

    def _on_mouse_click(self, gesture, n_press, x, y):
        for pnum, (bx, by, bw, bh, gp, name) in self.pin_hitboxes.items():
            if bx <= x <= bx + bw and by <= y <= by + bh:
                if gp is not None:
                    self.selected_pin = gp
                    self.queue_draw()
                    if self.on_pin_selected:
                        self.on_pin_selected(gp, pnum)
                break

    def _draw_board(self, area, cr, width, height):
        self.pin_hitboxes.clear()
        
        # Calculate board dimensions and center
        bw = min(360, width - 240)
        bh = min(620, height - 40)
        bx = (width - bw) / 2.0
        by = (height - bh) / 2.0
        
        # 1. Draw PCB Background (RP Green / Deep Teal)
        cr.save()
        cr.set_source_rgb(0.08, 0.28, 0.20)  # Classic RP Green
        self._rounded_rect(cr, bx, by, bw, bh, 14)
        cr.fill_preserve()
        cr.set_line_width(2.5)
        cr.set_source_rgb(0.15, 0.45, 0.32)
        cr.stroke()
        cr.restore()
        
        # 2. Draw Micro-USB Jack at top
        usb_w = 70
        usb_h = 24
        usb_x = bx + (bw - usb_w) / 2.0
        usb_y = by - 10
        cr.set_source_rgb(0.75, 0.77, 0.80)  # Silver/metallic
        self._rounded_rect(cr, usb_x, usb_y, usb_w, usb_h, 4)
        cr.fill_preserve()
        cr.set_source_rgb(0.4, 0.4, 0.4)
        cr.set_line_width(1.5)
        cr.stroke()
        
        # USB text
        cr.set_source_rgb(0.2, 0.2, 0.2)
        cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(9)
        cr.move_to(usb_x + 18, usb_y + 16)
        cr.show_text("USB CDC")
        
        # 3. Draw BOOTSEL Button
        btn_w, btn_h = 28, 20
        btn_x = bx + bw/2.0 - 55
        btn_y = by + 36
        cr.set_source_rgb(0.9, 0.9, 0.9)
        self._rounded_rect(cr, btn_x, btn_y, btn_w, btn_h, 3)
        cr.fill()
        cr.set_source_rgb(0.8, 0.2, 0.2)  # Red actuator
        self._rounded_rect(cr, btn_x + 5, btn_y + 4, btn_w - 10, btn_h - 8, 2)
        cr.fill()
        
        # 4. Draw Onboard LED (GP25)
        led_x = bx + bw/2.0 + 40
        led_y = by + 46
        cr.arc(led_x, led_y, 7, 0, 2 * math.pi)
        if self.led_on:
            cr.set_source_rgb(0.2, 0.95, 0.3)
            cr.fill_preserve()
            cr.set_source_rgba(0.2, 0.95, 0.3, 0.6)
            cr.set_line_width(6)
            cr.stroke()
        else:
            cr.set_source_rgb(0.2, 0.35, 0.25)
            cr.fill_preserve()
            cr.set_source_rgb(0.1, 0.2, 0.15)
            cr.set_line_width(1.5)
            cr.stroke()
        
        # LED Label
        cr.set_source_rgb(0.9, 0.9, 0.9)
        cr.set_font_size(8)
        cr.move_to(led_x - 8, led_y + 18)
        cr.show_text("LED")
        
        # 5. Draw RP2350 Microcontroller Chip in center
        chip_size = 90
        chip_x = bx + (bw - chip_size) / 2.0
        chip_y = by + (bh - chip_size) / 2.0 - 20
        cr.set_source_rgb(0.12, 0.13, 0.15)  # Dark matte silicon
        self._rounded_rect(cr, chip_x, chip_y, chip_size, chip_size, 6)
        cr.fill_preserve()
        cr.set_source_rgb(0.25, 0.26, 0.28)
        cr.set_line_width(1.5)
        cr.stroke()
        
        # Chip Silkscreen / Telemetry
        cr.set_source_rgb(0.85, 0.85, 0.85)
        cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(10)
        cr.move_to(chip_x + 16, chip_y + 24)
        cr.show_text("RP2350")
        
        cr.set_source_rgb(0.5, 0.8, 1.0)
        cr.set_font_size(8.5)
        cr.move_to(chip_x + 14, chip_y + 44)
        cr.show_text("150.0 MHz")
        
        cr.set_source_rgb(0.95, 0.85, 0.2)
        cr.move_to(chip_x + 14, chip_y + 64)
        cr.show_text(f"Temp: {self.temp_c:.1f}°C")
        
        # Board branding silkscreen
        cr.set_source_rgb(0.8, 0.9, 0.85)
        cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(12)
        cr.move_to(bx + 35, by + bh - 60)
        cr.show_text("Raspberry Pi Pico 2")
        
        cr.set_font_size(9)
        cr.set_source_rgb(0.65, 0.75, 0.70)
        cr.move_to(bx + 75, by + bh - 40)
        cr.show_text("RP2350 Dual-Core ARM")

        # 6. Draw Left & Right Pin Headers
        num_pins_side = 20
        pin_spacing = (bh - 60) / (num_pins_side - 1)
        start_y = by + 30
        
        # Left pins: 1 to 20
        for i in range(num_pins_side):
            pin_num = i + 1
            pinfo = PICO_PINS[pin_num]
            py = start_y + i * pin_spacing
            px = bx
            self._draw_pin_pad(cr, pin_num, pinfo, px, py, is_left=True, width=width)

        # Right pins: 40 down to 21
        for i in range(num_pins_side):
            pin_num = 40 - i
            pinfo = PICO_PINS[pin_num]
            py = start_y + i * pin_spacing
            px = bx + bw
            self._draw_pin_pad(cr, pin_num, pinfo, px, py, is_left=False, width=width)

    def _draw_pin_pad(self, cr, pin_num, pinfo, px, py, is_left, width):
        pad_w = 18
        pad_h = 16
        pad_x = px - (pad_w - 4) if is_left else px - 4
        pad_y = py - pad_h / 2.0
        
        gp = pinfo['gp']
        ptype = pinfo['type']
        name = pinfo['name']
        
        # Register hitbox for mouse click / hover
        hit_w = 120
        hit_x = pad_x - hit_w + pad_w if is_left else pad_x
        self.pin_hitboxes[pin_num] = (hit_x, pad_y - 2, hit_w, pad_h + 4, gp, name)
        
        is_hovered = (self.hovered_pin == pin_num)
        is_selected = (gp is not None and self.selected_pin == gp)
        
        # Castellated gold pad
        cr.save()
        if is_selected:
            cr.set_source_rgb(0.2, 0.8, 1.0)  # Cyan highlight for selected
        elif is_hovered:
            cr.set_source_rgb(1.0, 0.9, 0.3)  # Yellow hover halo
        else:
            cr.set_source_rgb(0.85, 0.70, 0.25)  # Gold pad
            
        self._rounded_rect(cr, pad_x, pad_y, pad_w, pad_h, 3)
        cr.fill_preserve()
        cr.set_source_rgb(0.2, 0.2, 0.2)
        cr.set_line_width(1.0)
        cr.stroke()
        
        # Hole in pad
        hole_x = pad_x + (5 if is_left else pad_w - 5)
        hole_y = py
        cr.arc(hole_x, hole_y, 3.5, 0, 2 * math.pi)
        cr.set_source_rgb(0.08, 0.08, 0.08)
        cr.fill()
        cr.restore()
        
        # Pin Number inside board margin
        cr.save()
        cr.set_source_rgb(0.9, 0.9, 0.9)
        cr.set_font_size(8)
        num_x = px + 12 if is_left else px - 22
        cr.move_to(num_x, py + 3)
        cr.show_text(str(pin_num))
        cr.restore()
        
        # Outer Label & State Badge outside the board
        cr.save()
        label_x = px - 28 if is_left else px + 28
        
        # Determine pin state styling
        badge_color = (0.5, 0.5, 0.5)  # Default gray
        badge_text = name
        
        st = self.pin_states.get(gp, {})
        mode = st.get('mode', 'IN')
        val = st.get('val', 0)
        
        if ptype == 'gnd':
            badge_color = (0.25, 0.25, 0.25)
        elif ptype == 'pwr':
            badge_color = (0.85, 0.25, 0.25)
        elif ptype == 'ctrl':
            badge_color = (0.7, 0.5, 0.2)
        elif mode == 'OUT':
            if val == 1:
                badge_color = (0.18, 0.76, 0.49)  # Glowing Green HIGH
            else:
                badge_color = (0.4, 0.45, 0.5)   # Slate LOW
        elif mode == 'PWM':
            badge_color = (0.96, 0.65, 0.14)      # Amber PWM
        elif mode == 'SERVO':
            badge_color = (0.16, 0.75, 0.75)      # Teal Servo
        elif ptype == 'adc':
            badge_color = (0.65, 0.35, 0.85)      # Purple ADC
        else: # IN
            badge_color = (0.21, 0.52, 0.89)      # Blue Input
            
        # Draw status badge pill
        pill_w = 68
        pill_h = 16
        pill_x = label_x - pill_w if is_left else label_x
        pill_y = py - pill_h / 2.0
        
        cr.set_source_rgb(*badge_color)
        self._rounded_rect(cr, pill_x, pill_y, pill_w, pill_h, 4)
        cr.fill_preserve()
        
        if is_selected:
            cr.set_source_rgb(1.0, 1.0, 1.0)
            cr.set_line_width(2.0)
            cr.stroke()
        else:
            cr.set_source_rgba(0, 0, 0, 0.3)
            cr.set_line_width(1.0)
            cr.stroke()
            
        # Text inside pill
        cr.set_source_rgb(1.0, 1.0, 1.0)
        cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(9)
        
        display_txt = name
        if gp is not None:
            if mode == 'OUT':
                display_txt = f"{name}: {'HIGH' if val else 'LOW'}"
            elif mode == 'PWM':
                display_txt = f"{name}: PWM"
            elif mode == 'SERVO':
                display_txt = f"{name}: {int(st.get('angle', 90))}°"
            elif ptype == 'adc':
                display_txt = f"{name} ADC"
        
        extents = cr.text_extents(display_txt)
        tx = pill_x + (pill_w - extents.width) / 2.0
        ty = py + extents.height / 2.0 - 1
        cr.move_to(tx, ty)
        cr.show_text(display_txt)
        cr.restore()

    def _rounded_rect(self, cr, x, y, w, h, r):
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
        cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
        cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
        cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()
