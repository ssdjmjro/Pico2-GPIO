"""
Pico Live Serial Terminal & Command Log View
"""

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib


class ConsoleView(Gtk.Box):
    def __init__(self, backend):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.backend = backend
        self.set_margin_top(12)
        self.set_margin_bottom(12)
        self.set_margin_start(16)
        self.set_margin_end(16)
        
        self.cmd_history = []
        self.history_idx = 0
        
        self._build_ui()

    def _build_ui(self):
        # Header Controls
        top_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        
        title = Gtk.Label(label="Live Serial Protocol Monitor")
        title.add_css_class("pico-header-title")
        title.set_hexpand(True)
        title.set_halign(Gtk.Align.START)
        top_box.append(title)
        
        btn_clear = Gtk.Button(label="🗑 Clear Log")
        btn_clear.connect("clicked", lambda b: self._clear_log())
        top_box.append(btn_clear)
        
        self.append(top_box)
        
        # Scrolled Text View
        scroll = Gtk.ScrolledWindow()
        scroll.set_hexpand(True)
        scroll.set_vexpand(True)
        scroll.set_min_content_height(320)
        
        self.text_view = Gtk.TextView()
        self.text_view.set_editable(False)
        self.text_view.set_cursor_visible(False)
        self.text_view.set_monospace(True)
        self.text_view.add_css_class("pico-console-view")
        self.text_view.set_wrap_mode(Gtk.WrapMode.CHAR)
        
        self.buffer = self.text_view.get_buffer()
        scroll.set_child(self.text_view)
        self.append(scroll)
        
        # Command Input Box Row
        input_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        
        self.entry_cmd = Gtk.Entry()
        self.entry_cmd.set_placeholder_text("Enter raw command (e.g. STATUS, DIGITAL_WRITE 15 1, PWM 15 1000 50, LED TOGGLE)...")
        self.entry_cmd.set_hexpand(True)
        self.entry_cmd.connect("activate", lambda e: self._send_command())
        input_box.append(self.entry_cmd)
        
        btn_send = Gtk.Button(label="Send ➔")
        btn_send.add_css_class("suggested-action")
        btn_send.connect("clicked", lambda b: self._send_command())
        input_box.append(btn_send)
        
        self.append(input_box)
        
        # Populate with existing backend logs
        for entry in self.backend.log_history:
            self.append_log(entry)

    def append_log(self, entry):
        t = entry.get('time', '')
        cmd = entry.get('cmd', '')
        resp = entry.get('resp', '')
        is_err = entry.get('is_err', False)
        
        status_tag = "🔴 [ERR]" if is_err else "🟢 [OK]"
        text = f"[{t}] TX ➔ {cmd}\n[{t}] RX ⇠ {status_tag} {resp}\n\n"
        
        end_iter = self.buffer.get_end_iter()
        self.buffer.insert(end_iter, text)
        
        # Auto-scroll to bottom
        mark = self.buffer.create_mark(None, self.buffer.get_end_iter(), False)
        self.text_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)

    def _clear_log(self):
        self.buffer.set_text("")
        self.backend.log_history.clear()

    def _send_command(self):
        cmd = self.entry_cmd.get_text().strip()
        if not cmd:
            return
        self.entry_cmd.set_text("")
        self.cmd_history.append(cmd)
        self.backend.send_raw(cmd)
