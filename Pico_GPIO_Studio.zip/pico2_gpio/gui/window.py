"""
Pico GPIO Studio Main Application Window
Full-featured GTK 4 & Libadwaita Desktop Control Center for Raspberry Pi Pico 2.
"""

import os
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, Gio, GLib

from .pico_backend import PicoBackend
from .widgets_board import PicoBoardCanvas
from .view_pins import PinControlStudioView
from .view_sequencer import SequencerView
from .view_i2c import I2CScannerView
from .view_telemetry import TelemetryView
from .view_console import ConsoleView
from pico_gpio import PicoGPIO


class PicoStudioWindow(Adw.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_title("Pico GPIO Studio")
        self.set_default_size(1200, 800)
        
        # Initialize Backend
        self.backend = PicoBackend(on_event=self._on_backend_event)
        
        # Build UI Structure
        self._build_ui()
        
        # Auto-connect on startup
        GLib.idle_add(self._auto_connect)

    def _build_ui(self):
        # Main vertical container with ToastOverlay
        self.toast_overlay = Adw.ToastOverlay()
        
        main_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.toast_overlay.set_child(main_vbox)
        self.set_content(self.toast_overlay)
        
        # Header Bar
        self.header_bar = Adw.HeaderBar()
        main_vbox.append(self.header_bar)
        
        # Header Title
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        lbl_app = Gtk.Label(label="Pico GPIO Studio")
        lbl_app.add_css_class("pico-header-title")
        title_box.append(lbl_app)
        
        # Connection Status Badge
        self.lbl_status = Gtk.Label(label="Connecting...")
        self.lbl_status.add_css_class("pico-badge-disconnected")
        title_box.append(self.lbl_status)
        self.header_bar.set_title_widget(title_box)
        
        # Header Start (Left) Widgets: Quick LED & Emergency Stop
        self.btn_led = Gtk.Button(label="💡 LED")
        self.btn_led.set_tooltip_text("Quick Toggle Onboard User LED (GP25)")
        self.btn_led.add_css_class("pico-led-btn")
        self.btn_led.connect("clicked", lambda b: self.backend.toggle_pin("LED"))
        self.header_bar.pack_start(self.btn_led)
        
        btn_emergency = Gtk.Button(label="🛑 All Off")
        btn_emergency.set_tooltip_text("Emergency Safe Stop: Turn off all outputs & park pins safely")
        btn_emergency.add_css_class("pico-emergency-btn")
        btn_emergency.connect("clicked", lambda b: self._emergency_stop())
        self.header_bar.pack_start(btn_emergency)
        
        # Header End (Right) Widgets: Connect / Port Menu & Simulation Toggle
        self.btn_connect = Gtk.Button(label="🔌 Ports")
        self.btn_connect.connect("clicked", lambda b: self._show_ports_menu())
        self.header_bar.pack_end(self.btn_connect)
        
        # Main Split Content Pane: Left = Visual Board, Right = ViewStack
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        paned.set_position(480)
        paned.set_hexpand(True)
        paned.set_vexpand(True)
        main_vbox.append(paned)
        
        # Left Pane: Interactive Visual Board
        left_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        left_box.set_size_request(440, -1)
        self.board_canvas = PicoBoardCanvas(on_pin_selected=self._on_board_pin_selected)
        left_box.append(self.board_canvas)
        paned.set_start_child(left_box)
        
        # Right Pane: ViewStack & ViewSwitcher
        right_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        right_box.set_hexpand(True)
        right_box.set_vexpand(True)
        
        # Top Tab Switcher
        self.view_stack = Adw.ViewStack()
        self.view_stack.set_hexpand(True)
        self.view_stack.set_vexpand(True)
        
        switcher = Adw.ViewSwitcher()
        switcher.set_stack(self.view_stack)
        switcher.set_policy(Adw.ViewSwitcherPolicy.WIDE)
        switcher.set_margin_top(6)
        switcher.set_margin_bottom(6)
        right_box.append(switcher)
        
        # Tab 1: Pin Control Studio
        self.view_pins = PinControlStudioView(self.backend, on_state_change=self._on_pin_studio_state_change)
        scroll_pins = Gtk.ScrolledWindow()
        scroll_pins.set_child(self.view_pins)
        self.view_stack.add_titled_with_icon(scroll_pins, "studio", "Pin Studio", "input-dialpad-symbolic")
        
        # Tab 2: Automation & Sequencer Lab
        self.view_sequencer = SequencerView(self.backend)
        self.view_stack.add_titled_with_icon(self.view_sequencer, "sequencer", "Automation Lab", "media-playback-start-symbolic")
        
        # Tab 3: I2C Scanner
        self.view_i2c = I2CScannerView(self.backend)
        scroll_i2c = Gtk.ScrolledWindow()
        scroll_i2c.set_child(self.view_i2c)
        self.view_stack.add_titled_with_icon(scroll_i2c, "i2c", "I2C Explorer", "system-search-symbolic")
        
        # Tab 4: System Telemetry & Diagnostics
        self.view_telemetry = TelemetryView(self.backend)
        scroll_telem = Gtk.ScrolledWindow()
        scroll_telem.set_child(self.view_telemetry)
        self.view_stack.add_titled_with_icon(scroll_telem, "telemetry", "Diagnostics", "preferences-system-details-symbolic")
        
        # Tab 5: Serial Protocol Terminal
        self.view_console = ConsoleView(self.backend)
        self.view_stack.add_titled_with_icon(self.view_console, "console", "Serial Console", "utilities-terminal-symbolic")
        
        right_box.append(self.view_stack)
        paned.set_end_child(right_box)

    def _auto_connect(self):
        """Attempt to connect to real hardware, otherwise fallback to simulator."""
        ok, msg = self.backend.connect()
        if not ok:
            # Fallback to simulation mode for seamless experience
            self.backend.connect(mock=True)
            self._show_toast("Started in Virtual Simulation Mode (Pico hardware not detected)")
        else:
            self._show_toast(f"Connected to Pico 2 on {self.backend.port_name}")

    def _emergency_stop(self):
        self.backend.emergency_all_off()
        self.board_canvas.update_led(False)
        for gp in range(29):
            self.board_canvas.update_pin_state(gp, mode='IN', val=0)
        self._show_toast("🛑 All pins safely parked & outputs turned off.")

    def _show_toast(self, text):
        toast = Adw.Toast.new(text)
        toast.set_timeout(3)
        self.toast_overlay.add_toast(toast)

    def _show_ports_menu(self):
        """Dialog to pick ports or switch between Real Hardware and Simulation."""
        dialog = Adw.MessageDialog(
            transient_for=self,
            heading="Connection Settings",
            body="Select serial communication port for Raspberry Pi Pico 2:"
        )
        
        ports = PicoGPIO.list_available_ports()
        p_names = [f"{p['device']} ({p['description']})" for p in ports]
        p_names.append("🔮 Simulation Mode (Virtual Pico)")
        
        group = Adw.PreferencesGroup()
        for idx, p in enumerate(ports):
            row = Adw.ActionRow()
            row.set_title(p['device'])
            row.set_subtitle(p['description'] + (" (Pico Detected)" if p['is_pico'] else ""))
            btn = Gtk.Button(label="Connect")
            btn.set_valign(Gtk.Align.CENTER)
            btn.connect("clicked", lambda b, dev=p['device']: self._connect_to_port(dev, False, dialog))
            row.add_suffix(btn)
            group.add(row)
            
        # Sim row
        sim_row = Adw.ActionRow()
        sim_row.set_title("Virtual Simulator")
        sim_row.set_subtitle("Simulate all GPIO pins, PWM, and ADC offline")
        btn_sim = Gtk.Button(label="Start Simulation")
        btn_sim.set_valign(Gtk.Align.CENTER)
        btn_sim.connect("clicked", lambda b: self._connect_to_port(None, True, dialog))
        sim_row.add_suffix(btn_sim)
        group.add(sim_row)
        
        dialog.set_extra_child(group)
        dialog.add_response("close", "Close")
        dialog.present()

    def _connect_to_port(self, port, is_mock, dialog):
        dialog.close()
        self.backend.connect(port=port, mock=is_mock)

    def _on_board_pin_selected(self, gp, pin_num):
        """When user clicks a pin on the Cairo visual board."""
        self.view_pins.set_active_pin(gp)
        # Switch tab to Studio if not already there
        self.view_stack.set_visible_child_name("studio")

    def _on_pin_studio_state_change(self, event_type, **kwargs):
        """Synchronize changes from Pin Studio to the visual board."""
        pin = kwargs.get('pin')
        if pin == "LED":
            return
        if event_type == 'pin_output':
            self.board_canvas.update_pin_state(pin, mode='OUT', val=kwargs.get('val'))
        elif event_type == 'pwm_active':
            self.board_canvas.update_pin_state(pin, mode='PWM', freq=kwargs.get('freq'), duty=kwargs.get('duty'))
        elif event_type == 'pwm_stopped':
            self.board_canvas.update_pin_state(pin, mode='IN', val=0)
        elif event_type == 'servo_angle':
            self.board_canvas.update_pin_state(pin, mode='SERVO', angle=kwargs.get('angle'))
        elif event_type == 'pin_selected':
            self.board_canvas.set_selected_pin(pin)

    def _on_backend_event(self, event):
        """Handle events from backend worker threads."""
        et = event.event_type
        d = event.data
        
        if et == 'connected':
            mock = d.get('mock', False)
            port = d.get('port', '')
            self.lbl_status.remove_css_class("pico-badge-disconnected")
            if mock:
                self.lbl_status.remove_css_class("pico-badge-connected")
                self.lbl_status.add_css_class("pico-badge-sim")
                self.lbl_status.set_text("🔮 Simulation Mode")
            else:
                self.lbl_status.remove_css_class("pico-badge-sim")
                self.lbl_status.add_css_class("pico-badge-connected")
                self.lbl_status.set_text(f"🟢 Connected: {port}")
                
        elif et == 'disconnected' or et == 'connection_error':
            self.lbl_status.remove_css_class("pico-badge-connected")
            self.lbl_status.remove_css_class("pico-badge-sim")
            self.lbl_status.add_css_class("pico-badge-disconnected")
            self.lbl_status.set_text("🔴 Disconnected")
            
        elif et == 'telemetry_temp':
            temp = d.get('temp', 25.0)
            self.board_canvas.update_temp(temp)
            self.view_telemetry.update_temp(temp)
            
        elif et == 'led_state_changed':
            st = d.get('state', 0)
            self.board_canvas.update_led(st)
            if st:
                self.btn_led.add_css_class("pico-led-on")
            else:
                self.btn_led.remove_css_class("pico-led-on")
                
        elif et == 'pin_digital_val':
            pin = d.get('pin')
            val = d.get('val')
            if pin == 'LED':
                self.board_canvas.update_led(val)
            else:
                self.board_canvas.update_pin_state(pin, val=val)
                self.view_pins.update_input_val(pin, val)
                
        elif et == 'adc_voltage':
            pin = d.get('pin')
            volts = d.get('volts')
            raw = d.get('raw')
            hist = d.get('history')
            self.view_pins.update_adc_data(pin, volts, raw, hist)
            
        elif et == 'seq_step_active':
            self.view_sequencer.highlight_step(d.get('step_index'))
            
        elif et == 'console_log':
            self.view_console.append_log(d.get('entry'))
            
        elif et == 'all_off':
            self.board_canvas.update_led(False)
            self.btn_led.remove_css_class("pico-led-on")
