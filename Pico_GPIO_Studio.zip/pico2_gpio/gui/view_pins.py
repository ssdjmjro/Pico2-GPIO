"""
Pico Pin Control Studio View
Unified controller for Digital Output, Input Polling, Hardware PWM, RC Servo, and ADC Voltmeter.
"""

import time
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib

from .pinout_data import PICO_PINS, GP_TO_PIN, ADC_PINS
from .widgets_oscilloscope import ADCOscilloscope
from .widgets_pwm import PWMWaveformVisualizer


class PinControlStudioView(Gtk.Box):
    def __init__(self, backend, on_state_change=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.backend = backend
        self.on_state_change = on_state_change
        self.set_margin_top(12)
        self.set_margin_bottom(12)
        self.set_margin_start(16)
        self.set_margin_end(16)
        
        self.current_pin = 15  # Default GP15
        self.current_mode = "OUT"
        
        # Blinker timer
        self.blink_active = False
        self.blink_timer_id = None
        self.blink_interval_ms = 250
        
        # Servo sweep timer
        self.servo_sweep_active = False
        self.servo_sweep_timer_id = None
        self.servo_angle = 90.0
        self.servo_sweep_dir = 1
        
        self._build_ui()

    def _build_ui(self):
        # Top Card: Pin Selector & Mode Switcher
        header_card = Adw.PreferencesGroup()
        header_card.set_title("Target Pin &amp; Operation Mode")
        
        # Pin Selector Row
        self.pin_combo_row = Adw.ComboRow()
        self.pin_combo_row.set_title("Select GPIO Pin")
        self.pin_combo_row.set_subtitle("GP0 to GP28, ADC channels, or Onboard LED")
        
        self.pin_list = []
        # LED first
        self.pin_list.append("LED (GP25 - Onboard LED)")
        # All GP pins
        for gp in range(29):
            pinfo = GP_TO_PIN.get(gp, {})
            alt = pinfo.get('alt', '')
            self.pin_list.append(f"GP{gp} (Pin {pinfo.get('num', '?')}) - {alt[:28]}")
            
        model = Gtk.StringList.new(self.pin_list)
        self.pin_combo_row.set_model(model)
        self.pin_combo_row.set_selected(16)  # Default GP15
        self.pin_combo_row.connect("notify::selected", self._on_pin_combo_changed)
        header_card.add(self.pin_combo_row)
        
        # Mode Switcher (ViewSwitcher / Segmented Button)
        mode_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        mode_box.set_homogeneous(True)
        mode_box.set_margin_top(6)
        mode_box.set_margin_bottom(6)
        
        self.btn_mode_out = Gtk.ToggleButton(label="⚡ Digital Output")
        self.btn_mode_in = Gtk.ToggleButton(label="📥 Digital Input")
        self.btn_mode_pwm = Gtk.ToggleButton(label="🌊 Hardware PWM")
        self.btn_mode_servo = Gtk.ToggleButton(label="🦾 RC Servo")
        self.btn_mode_adc = Gtk.ToggleButton(label="📊 Analog ADC")
        
        self.btn_mode_out.set_active(True)
        
        self.btn_mode_out.connect("toggled", lambda b: self._select_mode("OUT") if b.get_active() else None)
        self.btn_mode_in.connect("toggled", lambda b: self._select_mode("IN") if b.get_active() else None)
        self.btn_mode_pwm.connect("toggled", lambda b: self._select_mode("PWM") if b.get_active() else None)
        self.btn_mode_servo.connect("toggled", lambda b: self._select_mode("SERVO") if b.get_active() else None)
        self.btn_mode_adc.connect("toggled", lambda b: self._select_mode("ADC") if b.get_active() else None)
        
        mode_box.append(self.btn_mode_out)
        mode_box.append(self.btn_mode_in)
        mode_box.append(self.btn_mode_pwm)
        mode_box.append(self.btn_mode_servo)
        mode_box.append(self.btn_mode_adc)
        
        header_card.add(mode_box)
        self.append(header_card)
        
        # Mode Sub-Views (Stack)
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        
        self._build_output_panel()
        self._build_input_panel()
        self._build_pwm_panel()
        self._build_servo_panel()
        self._build_adc_panel()
        
        self.append(self.stack)

    def _select_mode(self, mode):
        self.current_mode = mode
        # Untoggle others
        self.btn_mode_out.set_active(mode == "OUT")
        self.btn_mode_in.set_active(mode == "IN")
        self.btn_mode_pwm.set_active(mode == "PWM")
        self.btn_mode_servo.set_active(mode == "SERVO")
        self.btn_mode_adc.set_active(mode == "ADC")
        
        self.stack.set_visible_child_name(mode)
        
        # If switching to ADC on non-ADC pin, notify
        if mode == "ADC" and self.current_pin not in ADC_PINS and self.current_pin != "LED":
            # auto-select GP26
            self.set_active_pin(26)

    def _on_pin_combo_changed(self, combo, param):
        idx = combo.get_selected()
        if idx == 0:
            pin = "LED"
        else:
            pin = idx - 1
        self.current_pin = pin
        if self.on_state_change:
            self.on_state_change('pin_selected', pin=pin)

    def set_active_pin(self, pin):
        """Called externally from visual board click."""
        self.current_pin = pin
        if pin == "LED":
            self.pin_combo_row.set_selected(0)
        elif isinstance(pin, int) and 0 <= pin <= 28:
            self.pin_combo_row.set_selected(pin + 1)

    # ---------------- Digital Output Panel ---------------- #
    def _build_output_panel(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        group = Adw.PreferencesGroup()
        group.set_title("Digital Output Control")
        group.set_description("Drive 3.3V logic HIGH (3.3V) or LOW (0V) directly to external circuits, LEDs, or relays.")
        
        # Big Toggle Row
        self.row_output_toggle = Adw.ActionRow()
        self.row_output_toggle.set_title("Logic Level (HIGH / LOW)")
        self.row_output_toggle.set_subtitle("3.3V logic level output")
        
        self.switch_out = Gtk.Switch()
        self.switch_out.set_valign(Gtk.Align.CENTER)
        self.switch_out.connect("state-set", self._on_output_switch_set)
        self.row_output_toggle.add_suffix(self.switch_out)
        group.add(self.row_output_toggle)
        
        # 1-Click Pulse Buttons Row
        pulse_row = Adw.ActionRow()
        pulse_row.set_title("One-Click Pulse")
        pulse_row.set_subtitle("Send a temporary HIGH pulse then automatically return LOW")
        
        pbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        pbox.set_valign(Gtk.Align.CENTER)
        for dur, lbl in [(50, "50ms"), (100, "100ms"), (250, "250ms"), (500, "500ms"), (1000, "1s")]:
            btn = Gtk.Button(label=lbl)
            btn.connect("clicked", lambda b, d=dur: self._trigger_pulse(d))
            pbox.append(btn)
        pulse_row.add_suffix(pbox)
        group.add(pulse_row)
        
        # Continuous Blinker Row
        blink_row = Adw.ActionRow()
        blink_row.set_title("Continuous Blink Generator")
        blink_row.set_subtitle("Oscillate pin continuously for testing or beacons")
        
        self.switch_blink = Gtk.Switch()
        self.switch_blink.set_valign(Gtk.Align.CENTER)
        self.switch_blink.connect("state-set", self._on_blink_switch_set)
        blink_row.add_suffix(self.switch_blink)
        group.add(blink_row)
        
        # Blink Interval Slider
        speed_row = Adw.ActionRow()
        speed_row.set_title("Blink Speed (Interval)")
        speed_row.set_subtitle("Delay between toggles in milliseconds")
        
        self.scale_blink = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 50, 1000, 50)
        self.scale_blink.set_value(250)
        self.scale_blink.set_hexpand(True)
        self.scale_blink.set_valign(Gtk.Align.CENTER)
        self.scale_blink.connect("value-changed", lambda s: setattr(self, 'blink_interval_ms', int(s.get_value())))
        speed_row.add_suffix(self.scale_blink)
        group.add(speed_row)
        
        box.append(group)
        self.stack.add_named(box, "OUT")

    def _on_output_switch_set(self, switch, state):
        self.backend.set_pin_mode(self.current_pin, "OUT")
        self.backend.write_pin(self.current_pin, 1 if state else 0)
        if self.on_state_change:
            self.on_state_change('pin_output', pin=self.current_pin, val=1 if state else 0)
        return False

    def _trigger_pulse(self, duration_ms):
        self.backend.set_pin_mode(self.current_pin, "OUT")
        self.backend.write_pin(self.current_pin, 1)
        self.switch_out.set_active(True)
        GLib.timeout_add(duration_ms, self._end_pulse)

    def _end_pulse(self):
        self.backend.write_pin(self.current_pin, 0)
        self.switch_out.set_active(False)
        return False

    def _on_blink_switch_set(self, switch, state):
        self.blink_active = state
        if state:
            self.backend.set_pin_mode(self.current_pin, "OUT")
            self._schedule_blink()
        else:
            if self.blink_timer_id:
                GLib.source_remove(self.blink_timer_id)
                self.blink_timer_id = None
            self.backend.write_pin(self.current_pin, 0)
            self.switch_out.set_active(False)
        return False

    def _schedule_blink(self):
        if self.blink_active:
            self.blink_timer_id = GLib.timeout_add(self.blink_interval_ms, self._blink_tick)

    def _blink_tick(self):
        if not self.blink_active:
            return False
        cur_v = self.switch_out.get_active()
        nv = not cur_v
        self.switch_out.set_active(nv)
        self.backend.write_pin(self.current_pin, 1 if nv else 0)
        self._schedule_blink()
        return False

    # ---------------- Digital Input Panel ---------------- #
    def _build_input_panel(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        group = Adw.PreferencesGroup()
        group.set_title("Digital Input &amp; Pull Resistors")
        group.set_description("Read digital buttons, sensors, logic signals with internal pull-up / pull-down.")
        
        # Pull Resistor Row
        pull_row = Adw.ActionRow()
        pull_row.set_title("Internal Pull Resistor")
        pull_row.set_subtitle("Select bias for floating pins or button contacts")
        
        pbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        pbox.set_valign(Gtk.Align.CENTER)
        self.btn_pull_up = Gtk.ToggleButton(label="Pull-Up (3.3V)")
        self.btn_pull_down = Gtk.ToggleButton(label="Pull-Down (0V)")
        self.btn_pull_none = Gtk.ToggleButton(label="Floating (None)")
        self.btn_pull_up.set_active(True)
        
        self.btn_pull_up.connect("toggled", lambda b: self._set_pull("IN_PULLUP") if b.get_active() else None)
        self.btn_pull_down.connect("toggled", lambda b: self._set_pull("IN_PULLDOWN") if b.get_active() else None)
        self.btn_pull_none.connect("toggled", lambda b: self._set_pull("IN") if b.get_active() else None)
        
        pbox.append(self.btn_pull_up)
        pbox.append(self.btn_pull_down)
        pbox.append(self.btn_pull_none)
        pull_row.add_suffix(pbox)
        group.add(pull_row)
        
        # Live State Readout Card
        read_row = Adw.ActionRow()
        read_row.set_title("Current Logic Level")
        read_row.set_subtitle("Live digital state of pin")
        
        self.lbl_in_val = Gtk.Label(label="LOW (0)")
        self.lbl_in_val.add_css_class("pico-voltage-display")
        self.lbl_in_val.set_valign(Gtk.Align.CENTER)
        read_row.add_suffix(self.lbl_in_val)
        group.add(read_row)
        
        # Read Now &amp; Live Polling
        mon_row = Adw.ActionRow()
        mon_row.set_title("Live Auto-Monitor")
        mon_row.set_subtitle("Continuously poll pin state in real time")
        
        btn_read_now = Gtk.Button(label="📖 Read Now")
        btn_read_now.set_valign(Gtk.Align.CENTER)
        btn_read_now.connect("clicked", lambda b: self._read_input_now())
        mon_row.add_suffix(btn_read_now)
        
        self.switch_in_mon = Gtk.Switch()
        self.switch_in_mon.set_valign(Gtk.Align.CENTER)
        self.switch_in_mon.connect("state-set", self._on_in_mon_toggled)
        mon_row.add_suffix(self.switch_in_mon)
        group.add(mon_row)
        
        box.append(group)
        self.stack.add_named(box, "IN")

    def _set_pull(self, mode):
        self.btn_pull_up.set_active(mode == "IN_PULLUP")
        self.btn_pull_down.set_active(mode == "IN_PULLDOWN")
        self.btn_pull_none.set_active(mode == "IN")
        self.backend.set_pin_mode(self.current_pin, mode)

    def _read_input_now(self):
        val = self.backend.read_pin(self.current_pin)
        self.update_input_val(self.current_pin, val)

    def _on_in_mon_toggled(self, switch, state):
        with self.backend.poll_lock:
            if state:
                if isinstance(self.current_pin, int):
                    self.backend.monitored_digital_pins.add(self.current_pin)
            else:
                if isinstance(self.current_pin, int):
                    self.backend.monitored_digital_pins.discard(self.current_pin)
        return False

    def update_input_val(self, pin, val):
        if pin == self.current_pin:
            self.lbl_in_val.set_text(f"{'HIGH (1)' if val else 'LOW (0)'}")

    # ---------------- Hardware PWM Panel ---------------- #
    def _build_pwm_panel(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        group = Adw.PreferencesGroup()
        group.set_title("Hardware PWM Generator")
        group.set_description("High precision hardware timer PWM for LED dimming, motor speed, tones, and power.")
        
        # Frequency Row
        freq_row = Adw.ActionRow()
        freq_row.set_title("PWM Frequency (Hz)")
        freq_row.set_subtitle("1 Hz to 100,000 Hz")
        
        self.spin_freq = Gtk.SpinButton.new_with_range(1, 100000, 100)
        self.spin_freq.set_value(1000)
        self.spin_freq.set_valign(Gtk.Align.CENTER)
        self.spin_freq.connect("value-changed", self._on_pwm_params_changed)
        freq_row.add_suffix(self.spin_freq)
        group.add(freq_row)
        
        # Quick Frequency Presets
        f_presets = Adw.ActionRow()
        f_presets.set_title("Frequency Presets")
        fp_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        fp_box.set_valign(Gtk.Align.CENTER)
        for f, lbl in [(100, "100Hz"), (1000, "1kHz"), (5000, "5kHz"), (10000, "10kHz"), (25000, "25kHz")]:
            btn = Gtk.Button(label=lbl)
            btn.connect("clicked", lambda b, freq=f: self.spin_freq.set_value(freq))
            fp_box.append(btn)
        f_presets.add_suffix(fp_box)
        group.add(f_presets)
        
        # Duty Cycle Slider Row
        duty_row = Adw.ActionRow()
        duty_row.set_title("Duty Cycle (%)")
        duty_row.set_subtitle("0.0% to 100.0% (0 - 65535 u16)")
        
        self.scale_duty = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0.0, 100.0, 1.0)
        self.scale_duty.set_value(50.0)
        self.scale_duty.set_hexpand(True)
        self.scale_duty.set_valign(Gtk.Align.CENTER)
        self.scale_duty.connect("value-changed", self._on_pwm_params_changed)
        duty_row.add_suffix(self.scale_duty)
        group.add(duty_row)
        
        # Duty Presets
        d_presets = Adw.ActionRow()
        d_presets.set_title("Duty Presets")
        dp_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        dp_box.set_valign(Gtk.Align.CENTER)
        for d, lbl in [(0, "0%"), (25, "25%"), (50, "50%"), (75, "75%"), (100, "100%")]:
            btn = Gtk.Button(label=lbl)
            btn.connect("clicked", lambda b, duty=d: self.scale_duty.set_value(duty))
            dp_box.append(btn)
        d_presets.add_suffix(dp_box)
        group.add(d_presets)
        
        # Apply &amp; Stop PWM Buttons
        ctrl_row = Adw.ActionRow()
        ctrl_row.set_title("Output Action")
        cbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        cbox.set_valign(Gtk.Align.CENTER)
        
        self.btn_apply_pwm = Gtk.Button(label="▶ Start / Update PWM")
        self.btn_apply_pwm.add_css_class("suggested-action")
        self.btn_apply_pwm.connect("clicked", lambda b: self._apply_pwm())
        
        self.btn_stop_pwm = Gtk.Button(label="⏹ Stop PWM")
        self.btn_stop_pwm.add_css_class("destructive-action")
        self.btn_stop_pwm.connect("clicked", lambda b: self._stop_pwm())
        
        cbox.append(self.btn_apply_pwm)
        cbox.append(self.btn_stop_pwm)
        ctrl_row.add_suffix(cbox)
        group.add(ctrl_row)
        
        # Waveform Graphic
        self.pwm_visualizer = PWMWaveformVisualizer()
        group.add(self.pwm_visualizer)
        
        box.append(group)
        self.stack.add_named(box, "PWM")

    def _on_pwm_params_changed(self, widget):
        freq = self.spin_freq.get_value()
        duty = self.scale_duty.get_value()
        self.pwm_visualizer.update_params(freq, duty, active=True)

    def _apply_pwm(self):
        freq = int(self.spin_freq.get_value())
        duty = float(self.scale_duty.get_value())
        self.backend.set_pwm(self.current_pin, freq, duty)
        self.pwm_visualizer.update_params(freq, duty, active=True)
        if self.on_state_change:
            self.on_state_change('pwm_active', pin=self.current_pin, freq=freq, duty=duty)

    def _stop_pwm(self):
        self.backend.stop_pwm(self.current_pin)
        self.pwm_visualizer.update_params(self.spin_freq.get_value(), 0, active=False)
        if self.on_state_change:
            self.on_state_change('pwm_stopped', pin=self.current_pin)

    # ---------------- RC Servo Panel ---------------- #
    def _build_servo_panel(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        group = Adw.PreferencesGroup()
        group.set_title("RC Servo Motor Controller")
        group.set_description("Standard 50Hz PWM pulse (0.5ms - 2.5ms) for SG90, MG996R, and robotic servos.")
        
        # Angle Slider Row
        angle_row = Adw.ActionRow()
        angle_row.set_title("Target Angle (Degrees)")
        angle_row.set_subtitle("0.0° to 180.0° position")
        
        self.scale_servo = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0.0, 180.0, 1.0)
        self.scale_servo.set_value(90.0)
        self.scale_servo.set_hexpand(True)
        self.scale_servo.set_valign(Gtk.Align.CENTER)
        self.scale_servo.connect("value-changed", self._on_servo_slider_changed)
        angle_row.add_suffix(self.scale_servo)
        group.add(angle_row)
        
        # Preset Buttons Row
        preset_row = Adw.ActionRow()
        preset_row.set_title("Angle Presets")
        pbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        pbox.set_valign(Gtk.Align.CENTER)
        for ang, lbl in [(0, "0° Min"), (45, "45°"), (90, "90° Center"), (135, "135°"), (180, "180° Max")]:
            btn = Gtk.Button(label=lbl)
            btn.connect("clicked", lambda b, a=ang: self.scale_servo.set_value(a))
            pbox.append(btn)
        preset_row.add_suffix(pbox)
        group.add(preset_row)
        
        # Auto Sweep Mode
        sweep_row = Adw.ActionRow()
        sweep_row.set_title("Auto-Sweep Test Mode")
        sweep_row.set_subtitle("Oscillate servo smoothly back and forth")
        
        self.switch_sweep = Gtk.Switch()
        self.switch_sweep.set_valign(Gtk.Align.CENTER)
        self.switch_sweep.connect("state-set", self._on_sweep_switch_set)
        sweep_row.add_suffix(self.switch_sweep)
        group.add(sweep_row)
        
        box.append(group)
        self.stack.add_named(box, "SERVO")

    def _on_servo_slider_changed(self, scale):
        angle = scale.get_value()
        self.servo_angle = angle
        self.backend.set_servo(self.current_pin, angle)
        if self.on_state_change:
            self.on_state_change('servo_angle', pin=self.current_pin, angle=angle)

    def _on_sweep_switch_set(self, switch, state):
        self.servo_sweep_active = state
        if state:
            self._schedule_sweep()
        else:
            if self.servo_sweep_timer_id:
                GLib.source_remove(self.servo_sweep_timer_id)
                self.servo_sweep_timer_id = None
        return False

    def _schedule_sweep(self):
        if self.servo_sweep_active:
            self.servo_sweep_timer_id = GLib.timeout_add(30, self._sweep_tick)

    def _sweep_tick(self):
        if not self.servo_sweep_active:
            return False
        cur = self.scale_servo.get_value()
        new_ang = cur + self.servo_sweep_dir * 2.0
        if new_ang >= 180.0:
            new_ang = 180.0
            self.servo_sweep_dir = -1
        elif new_ang <= 0.0:
            new_ang = 0.0
            self.servo_sweep_dir = 1
        self.scale_servo.set_value(new_ang)
        self._schedule_sweep()
        return False

    # ---------------- Analog ADC Panel ---------------- #
    def _build_adc_panel(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        group = Adw.PreferencesGroup()
        group.set_title("Analog ADC Voltmeter &amp; Oscilloscope")
        group.set_description("High speed 16-bit analog input (0.000V to 3.300V) on GP26, GP27, GP28.")
        
        # Voltmeter Card
        volt_row = Adw.ActionRow()
        volt_row.set_title("Measured Voltage &amp; Raw ADC")
        volt_row.set_subtitle("GP26 (ADC0), GP27 (ADC1), or GP28 (ADC2)")
        
        self.lbl_adc_volts = Gtk.Label(label="0.000 V")
        self.lbl_adc_volts.add_css_class("pico-voltage-display")
        self.lbl_adc_volts.set_valign(Gtk.Align.CENTER)
        volt_row.add_suffix(self.lbl_adc_volts)
        group.add(volt_row)
        
        # Controls Row
        ctrl_row = Adw.ActionRow()
        ctrl_row.set_title("Live Oscilloscope Stream")
        ctrl_row.set_subtitle("Stream live rolling waveform")
        
        cbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        cbox.set_valign(Gtk.Align.CENTER)
        
        btn_sample_now = Gtk.Button(label="⚡ Sample Once")
        btn_sample_now.connect("clicked", lambda b: self._sample_adc_now())
        
        btn_clear_graph = Gtk.Button(label="🗑 Clear Graph")
        btn_clear_graph.connect("clicked", lambda b: self.scope_widget.clear())
        
        self.switch_adc_stream = Gtk.Switch()
        self.switch_adc_stream.connect("state-set", self._on_adc_stream_toggled)
        
        cbox.append(btn_sample_now)
        cbox.append(btn_clear_graph)
        cbox.append(self.switch_adc_stream)
        ctrl_row.add_suffix(cbox)
        group.add(ctrl_row)
        
        # Embedded Oscilloscope Widget
        self.scope_widget = ADCOscilloscope()
        group.add(self.scope_widget)
        
        box.append(group)
        self.stack.add_named(box, "ADC")

    def _sample_adc_now(self):
        adc_pin = self.current_pin if self.current_pin in ADC_PINS else 26
        data = self.backend.read_adc(adc_pin)
        self.update_adc_data(adc_pin, data['volts'], data['raw'])

    def _on_adc_stream_toggled(self, switch, state):
        adc_pin = self.current_pin if self.current_pin in ADC_PINS else 26
        with self.backend.poll_lock:
            if state:
                self.backend.monitored_adc_pins.add(adc_pin)
            else:
                self.backend.monitored_adc_pins.discard(adc_pin)
        return False

    def update_adc_data(self, pin, volts, raw, history=None):
        if pin == self.current_pin or (self.current_pin not in ADC_PINS and pin == 26):
            self.lbl_adc_volts.set_text(f"{volts:.3f} V")
            self.scope_widget.add_sample(volts, raw, pin_name=f"GP{pin} (ADC)")
