#!/usr/bin/env python3
"""
Pico 2 I2C Scanner
Scans GP4 (SDA) and GP5 (SCL) for connected I2C devices like the PN532 NFC module.
"""
import serial
import time
import sys

def main():
    print("\033[1m\033[96m⚡ Scanning I2C Bus on Pico 2 (GP4=SDA, GP5=SCL)...\033[0m")
    try:
        ser = serial.Serial('/dev/ttyACM0', 115200, timeout=2)
    except Exception as e:
        print(f"\033[91mError connecting to /dev/ttyACM0:\033[0m {e}")
        sys.exit(1)

    ser.dtr = True
    ser.rts = False
    
    # Enter raw REPL
    ser.write(b'\x03\x03\x01')
    time.sleep(0.1)
    ser.reset_input_buffer()
    
    # Run scan
    code = "import machine\r\ni2c=machine.I2C(0,sda=machine.Pin(4),scl=machine.Pin(5),freq=100000)\r\nprint('DEV_LIST:', i2c.scan())\r\n"
    ser.write(code.encode() + b'\x04')
    time.sleep(0.3)
    resp = ser.read_until(b'\x04>').decode(errors='replace')
    
    # Restore normal mode
    ser.write(b'\x02\x04')
    time.sleep(0.2)
    ser.close()
    
    # Process results
    devs = []
    for line in resp.splitlines():
        if "DEV_LIST:" in line:
            raw_str = line.split("DEV_LIST:")[1].strip()
            try:
                devs = eval(raw_str)
            except Exception:
                pass
                
    if not devs:
        print("\n\033[93m⚠️  No I2C devices detected on GP4 / GP5.\033[0m")
        print("Check:")
        print("  1. VCC -> Pico 2 Pin 36 (3V3)")
        print("  2. GND -> Pico 2 Pin 38 (GND)")
        print("  3. SDA -> Pico 2 GP4 (Pin 6)")
        print("  4. SCL -> Pico 2 GP5 (Pin 7)")
        print("  5. PN532 DIP switches: Switch 1 = 0 (OFF), Switch 2 = 1 (ON)")
    else:
        hex_addrs = [hex(d) for d in devs]
        print(f"\n\033[92m✓ Found I2C Devices:\033[0m {hex_addrs}")
        if 0x24 in devs or 36 in devs:
            print("\033[1m\033[92m✅ PN532 NFC Module detected successfully at Address 0x24!\033[0m")
        else:
            print("ℹ️  Found other device address(es):", hex_addrs)

if __name__ == "__main__":
    main()
