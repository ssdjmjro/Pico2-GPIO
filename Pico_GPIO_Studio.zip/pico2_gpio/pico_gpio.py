"""
Pico 2 GPIO Controller for Ubuntu Linux
Control Raspberry Pi Pico 2 (RP2350) GPIO pins directly over USB Serial.
Thread-safe, high performance, with support for Mock/Simulation mode.
"""

import sys
import time
import math
import random
import threading
import serial
import serial.tools.list_ports

# Pin Modes
IN = "IN"
OUT = "OUT"
IN_PULLUP = "IN_PULLUP"
IN_PULLDOWN = "IN_PULLDOWN"
PULL_UP = IN_PULLUP
PULL_DOWN = IN_PULLDOWN

# Logic Levels
HIGH = 1
LOW = 0


class PicoGPIOError(Exception):
    pass


class PicoGPIO:
    """Raspberry Pi Pico 2 USB GPIO Controller interface."""
    
    # Raspberry Pi Pico / RP2350 USB VID
    PICO_VID = 0x2E8A
    
    def __init__(self, port=None, baudrate=115200, timeout=1.0, auto_connect=True, mock=False, log_callback=None):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.ser = None
        self.mock = mock
        self.lock = threading.RLock()
        self.log_callback = log_callback
        
        # Internal state tracking for GUI/telemetry
        self.pin_states = {}  # pin -> {'mode': 'OUT', 'value': 0, 'freq': None, 'duty': None, 'angle': None}
        self.led_state = 0
        self.mock_temp = 26.5
        self.mock_adc_phase = 0.0
        
        if auto_connect and not self.mock:
            try:
                self.connect()
            except PicoGPIOError as e:
                # If auto-connect fails and user didn't explicitly specify a port, fall back to mock if requested
                raise e
        elif self.mock:
            self._init_mock()

    def _init_mock(self):
        """Initialize mock simulation environment."""
        self.mock = True
        self.port = "SIMULATOR (Virtual Pico 2)"
        self.pin_states = {
            i: {'mode': 'IN', 'value': 0, 'freq': 1000, 'duty': 0, 'angle': 90} for i in range(29)
        }
        self.pin_states['LED'] = {'mode': 'OUT', 'value': 0, 'freq': None, 'duty': None, 'angle': None}

    @classmethod
    def list_available_ports(cls):
        """List all candidate serial ports with descriptions."""
        ports = serial.tools.list_ports.comports()
        result = []
        for p in ports:
            is_pico = (p.vid == cls.PICO_VID) or ("micropython" in (p.description or "").lower()) or ("pico" in (p.description or "").lower())
            result.append({
                'device': p.device,
                'description': p.description or "Serial Device",
                'is_pico': is_pico,
                'vid': p.vid,
                'pid': p.pid
            })
        return result

    @classmethod
    def find_pico_port(cls):
        """Automatically find connected Raspberry Pi Pico 2 serial port."""
        ports = serial.tools.list_ports.comports()
        
        # Priority 1: Check by Raspberry Pi VID
        for p in ports:
            if p.vid == cls.PICO_VID:
                return p.device
                
        # Priority 2: Check by description
        for p in ports:
            desc = (p.description or "").lower()
            if "micropython" in desc or "pico" in desc or "rp2350" in desc:
                return p.device
                
        # Priority 3: Check /dev/ttyACM*
        for p in ports:
            if p.device and p.device.startswith("/dev/ttyACM"):
                return p.device
                
        return None

    def connect(self):
        """Open connection to the Pico 2."""
        with self.lock:
            if self.mock:
                self._init_mock()
                return

            if not self.port:
                self.port = self.find_pico_port()
                if not self.port:
                    raise PicoGPIOError("Raspberry Pi Pico 2 not found! Please check USB cable connection.")
                    
            try:
                self.ser = serial.Serial(self.port, self.baudrate, timeout=self.timeout)
                self.ser.dtr = True
                self.ser.rts = False
                time.sleep(0.05)
                
                # Verify communication
                if not self.ping():
                    # Try waking up the serial server
                    self.ser.write(b"\r\n")
                    time.sleep(0.05)
                    if not self.ping():
                        raise PicoGPIOError(f"Connected to {self.port} but Pico 2 GPIO server did not respond to PING.")
            except serial.SerialException as e:
                raise PicoGPIOError(f"Failed to open port {self.port}: {e}")

    def is_connected(self):
        """Check if connection is alive."""
        if self.mock:
            return True
        return self.ser is not None and self.ser.is_open

    def _log(self, cmd, resp, is_err=False):
        if self.log_callback:
            try:
                self.log_callback(cmd, resp, is_err)
            except Exception:
                pass

    def send_command(self, cmd_str):
        """Send a raw command string and return the response."""
        with self.lock:
            cmd_clean = cmd_str.strip()
            
            if self.mock:
                resp = self._mock_process_command(cmd_clean)
                self._log(cmd_clean, resp, resp.startswith("ERR:"))
                return resp
                
            if not self.ser or not self.ser.is_open:
                err = "Serial port is not open."
                self._log(cmd_clean, f"ERR: {err}", True)
                raise PicoGPIOError(err)
                
            try:
                self.ser.reset_input_buffer()
                self.ser.write((cmd_clean + "\n").encode("utf-8"))
                
                line = self.ser.readline().decode("utf-8", errors="replace").strip()
                if not line:
                    # Retry once
                    time.sleep(0.05)
                    line = self.ser.readline().decode("utf-8", errors="replace").strip()
                    
                if not line:
                    raise PicoGPIOError("Timeout waiting for response from Pico 2.")
                    
                is_err = line.startswith("ERR:")
                self._log(cmd_clean, line, is_err)
                if is_err:
                    raise PicoGPIOError(line)
                return line
            except serial.SerialException as e:
                self._log(cmd_clean, f"ERR: {e}", True)
                raise PicoGPIOError(f"Serial communication error: {e}")

    def _mock_process_command(self, cmd_str):
        """Handle mock command execution for offline / simulated testing."""
        parts = cmd_str.split()
        if not parts:
            return ""
        cmd = parts[0].upper()
        
        if cmd == "PING":
            return "PONG"
        elif cmd in ("STATUS", "INFO"):
            active = [k for k, v in self.pin_states.items() if v.get('mode') == 'OUT']
            pwms = [k for k, v in self.pin_states.items() if v.get('mode') == 'PWM']
            temp = self.mock_temp + random.uniform(-0.2, 0.2)
            return f"INFO: PLATFORM=rp2 (SIMULATED), VERSION=1.0.0-RP2350, FREQ=150000000, TEMP={temp:.1f}C, ACTIVE_PINS={active}, PWM_PINS={pwms}"
        elif cmd == "PIN_MODE":
            pin = parts[1].upper().replace("GP", "")
            pin = "LED" if pin == "LED" else int(pin)
            mode = parts[2].upper()
            if pin not in self.pin_states:
                self.pin_states[pin] = {}
            self.pin_states[pin]['mode'] = mode
            return f"OK: PIN_MODE {pin} {mode}"
        elif cmd in ("DIGITAL_WRITE", "WRITE"):
            pin = parts[1].upper().replace("GP", "")
            pin = "LED" if pin == "LED" else int(pin)
            val = 1 if parts[2] in ("1", "HIGH", "TRUE", "ON", "true", "on") else 0
            if pin not in self.pin_states:
                self.pin_states[pin] = {'mode': 'OUT'}
            self.pin_states[pin]['value'] = val
            if pin == "LED":
                self.led_state = val
            return f"OK: DIGITAL_WRITE {pin} {val}"
        elif cmd in ("DIGITAL_READ", "READ"):
            pin = parts[1].upper().replace("GP", "")
            pin = "LED" if pin == "LED" else int(pin)
            pinfo = self.pin_states.get(pin, {})
            mode = pinfo.get('mode', 'IN')
            if mode == 'IN_PULLUP':
                val = 1
            elif mode == 'IN_PULLDOWN':
                val = 0
            else:
                val = pinfo.get('value', 0)
            return f"VAL:{val}"
        elif cmd == "TOGGLE":
            pin = parts[1].upper().replace("GP", "")
            pin = "LED" if pin == "LED" else int(pin)
            cur = self.pin_states.get(pin, {}).get('value', 0)
            nv = 0 if cur else 1
            if pin not in self.pin_states:
                self.pin_states[pin] = {'mode': 'OUT'}
            self.pin_states[pin]['value'] = nv
            if pin == "LED":
                self.led_state = nv
            return f"VAL:{nv}"
        elif cmd in ("ANALOG_READ", "ADC"):
            arg = parts[1].upper()
            if arg in ("TEMP", "4"):
                self.mock_temp += random.uniform(-0.1, 0.1)
                self.mock_temp = max(20.0, min(45.0, self.mock_temp))
                voltage = 0.706 - (self.mock_temp - 27.0) * 0.001721
                raw = int((voltage / 3.3) * 65535)
                return f"TEMP:{self.mock_temp:.2f},RAW:{raw},VOLTS:{voltage:.4f}"
            else:
                self.mock_adc_phase += 0.15
                v = 1.65 + 1.4 * math.sin(self.mock_adc_phase) + random.uniform(-0.02, 0.02)
                v = max(0.0, min(3.3, v))
                raw = int((v / 3.3) * 65535)
                return f"RAW:{raw},VOLTS:{v:.4f}"
        elif cmd == "PWM":
            pin = int(parts[1].upper().replace("GP", ""))
            freq = int(float(parts[2]))
            duty = float(parts[3])
            self.pin_states[pin] = {'mode': 'PWM', 'freq': freq, 'duty': duty, 'value': 1 if duty > 0 else 0}
            duty_u16 = int((duty / 100.0) * 65535) if duty <= 100 else int(duty)
            return f"OK: PWM {pin} FREQ={freq} DUTY={duty_u16}"
        elif cmd == "PWM_STOP":
            pin = int(parts[1].upper().replace("GP", ""))
            if pin in self.pin_states:
                self.pin_states[pin]['mode'] = 'IN'
                self.pin_states[pin]['duty'] = 0
            return f"OK: PWM_STOP {pin}"
        elif cmd == "SERVO":
            pin = int(parts[1].upper().replace("GP", ""))
            angle = float(parts[2])
            self.pin_states[pin] = {'mode': 'SERVO', 'angle': angle}
            return f"OK: SERVO {pin} ANGLE={angle:.1f}"
        elif cmd == "LED":
            action = parts[1].upper()
            if action in ("ON", "1"):
                self.led_state = 1
            elif action in ("OFF", "0"):
                self.led_state = 0
            elif action in ("TOGGLE", "TOG"):
                self.led_state = 0 if self.led_state else 1
            self.pin_states['LED'] = {'mode': 'OUT', 'value': self.led_state}
            return f"OK: LED {self.led_state}"
        elif cmd == "I2C_SCAN":
            return "DEVS:0x24,0x3c,0x68"
        elif cmd in ("RESET", "REBOOT"):
            self._init_mock()
            return "OK: REBOOTING"
        elif cmd == "ALL_OFF":
            self.led_state = 0
            for k in self.pin_states:
                self.pin_states[k]['value'] = 0
                self.pin_states[k]['mode'] = 'IN'
            return "OK: ALL_OFF"
        else:
            return f"ERR: Unknown command '{cmd}'"

    def ping(self):
        """Send PING to check responsiveness."""
        try:
            resp = self.send_command("PING")
            return resp == "PONG"
        except Exception:
            return False

    def pin_mode(self, pin, mode=OUT):
        """Set GPIO pin mode (IN, OUT, IN_PULLUP, IN_PULLDOWN)."""
        mode_str = str(mode).upper()
        res = self.send_command(f"PIN_MODE {pin} {mode_str}")
        pin_key = "LED" if str(pin).upper() == "LED" else int(str(pin).replace("GP", ""))
        if pin_key not in self.pin_states:
            self.pin_states[pin_key] = {}
        self.pin_states[pin_key]['mode'] = mode_str
        return res

    def setup(self, pin, mode=OUT):
        """RPi.GPIO compatibility alias for pin_mode."""
        return self.pin_mode(pin, mode)

    def digital_write(self, pin, value):
        """Set GPIO pin output value (HIGH/LOW or 1/0)."""
        val_int = 1 if value in (1, True, "1", "HIGH", "high", "ON", "on") else 0
        res = self.send_command(f"DIGITAL_WRITE {pin} {val_int}")
        pin_key = "LED" if str(pin).upper() == "LED" else int(str(pin).replace("GP", ""))
        if pin_key not in self.pin_states:
            self.pin_states[pin_key] = {'mode': 'OUT'}
        self.pin_states[pin_key]['value'] = val_int
        if pin_key == "LED":
            self.led_state = val_int
        return res

    def output(self, pin, value):
        """RPi.GPIO compatibility alias for digital_write."""
        return self.digital_write(pin, value)

    def digital_read(self, pin):
        """Read digital value of GPIO pin (returns 0 or 1)."""
        resp = self.send_command(f"DIGITAL_READ {pin}")
        val = 0
        if resp.startswith("VAL:"):
            val = int(resp.split(":")[1])
        pin_key = "LED" if str(pin).upper() == "LED" else int(str(pin).replace("GP", ""))
        if pin_key not in self.pin_states:
            self.pin_states[pin_key] = {'mode': 'IN'}
        self.pin_states[pin_key]['value'] = val
        return val

    def input(self, pin):
        """RPi.GPIO compatibility alias for digital_read."""
        return self.digital_read(pin)

    def toggle(self, pin):
        """Toggle digital pin state and return new value."""
        resp = self.send_command(f"TOGGLE {pin}")
        val = 0
        if resp.startswith("VAL:"):
            val = int(resp.split(":")[1])
        pin_key = "LED" if str(pin).upper() == "LED" else int(str(pin).replace("GP", ""))
        if pin_key not in self.pin_states:
            self.pin_states[pin_key] = {'mode': 'OUT'}
        self.pin_states[pin_key]['value'] = val
        if pin_key == "LED":
            self.led_state = val
        return val

    def led(self, state=None):
        """Control or toggle onboard LED. Pass True/1 for ON, False/0 for OFF, None to TOGGLE."""
        if state is None:
            res = self.send_command("LED TOGGLE")
        elif state in (True, 1, "ON", "on", "1"):
            res = self.send_command("LED ON")
        else:
            res = self.send_command("LED OFF")
            
        if "OK: LED 1" in res:
            self.led_state = 1
        elif "OK: LED 0" in res:
            self.led_state = 0
        self.pin_states['LED'] = {'mode': 'OUT', 'value': self.led_state}
        return res

    def analog_read(self, pin):
        """Read 16-bit raw ADC value (0-65535) on GP26 (ADC0), GP27 (ADC1), GP28 (ADC2)."""
        resp = self.send_command(f"ANALOG_READ {pin}")
        parts = dict(item.split(":") for item in resp.split(","))
        return int(parts.get("RAW", 0))

    def analog_read_voltage(self, pin):
        """Read analog voltage (0.0V - 3.3V) on GP26, GP27, GP28."""
        resp = self.send_command(f"ANALOG_READ {pin}")
        parts = dict(item.split(":") for item in resp.split(","))
        return float(parts.get("VOLTS", 0.0))

    def analog_read_full(self, pin):
        """Read both raw value and calibrated voltage."""
        resp = self.send_command(f"ANALOG_READ {pin}")
        parts = dict(item.split(":") for item in resp.split(","))
        return {
            'raw': int(parts.get("RAW", 0)),
            'volts': float(parts.get("VOLTS", 0.0)),
            'temp': float(parts.get("TEMP", 0.0)) if "TEMP" in parts else None
        }

    def get_internal_temp(self):
        """Read Pico 2 onboard RP2350 internal temperature in Celsius."""
        resp = self.send_command("ANALOG_READ TEMP")
        parts = dict(item.split(":") for item in resp.split(","))
        return float(parts.get("TEMP", 0.0))

    def pwm(self, pin, freq=1000, duty=50.0):
        """Set PWM frequency (Hz) and duty cycle (0-100% or 0-65535)."""
        res = self.send_command(f"PWM {pin} {freq} {duty}")
        pin_key = int(str(pin).replace("GP", ""))
        self.pin_states[pin_key] = {'mode': 'PWM', 'freq': freq, 'duty': duty, 'value': 1 if duty > 0 else 0}
        return res

    def pwm_stop(self, pin):
        """De-initialize and stop PWM on pin."""
        res = self.send_command(f"PWM_STOP {pin}")
        pin_key = int(str(pin).replace("GP", ""))
        if pin_key in self.pin_states:
            self.pin_states[pin_key]['mode'] = 'IN'
            self.pin_states[pin_key]['duty'] = 0
        return res

    def servo(self, pin, angle_deg):
        """Control standard 50Hz RC servo motor (angle 0.0 to 180.0 degrees)."""
        res = self.send_command(f"SERVO {pin} {angle_deg}")
        pin_key = int(str(pin).replace("GP", ""))
        self.pin_states[pin_key] = {'mode': 'SERVO', 'angle': angle_deg}
        return res

    def i2c_scan(self, sda_pin=4, scl_pin=5, bus_id=0):
        """Scan I2C bus for connected slave devices."""
        try:
            resp = self.send_command(f"I2C_SCAN {sda_pin} {scl_pin} {bus_id}")
            if resp.startswith("DEVS:"):
                dev_str = resp[5:].strip()
                if not dev_str:
                    return []
                return [d.strip() for d in dev_str.split(",") if d.strip()]
        except Exception:
            pass
        return []

    def all_off(self):
        """Safety stop: Turn off LED, stop PWM, set all pins to safe Input mode."""
        with self.lock:
            try:
                self.send_command("ALL_OFF")
            except Exception:
                pass
            try:
                self.led(False)
            except Exception:
                pass
            for pin in range(29):
                try:
                    self.pwm_stop(pin)
                    self.pin_mode(pin, IN)
                except Exception:
                    pass
            self.led_state = 0
            self.pin_states = {i: {'mode': 'IN', 'value': 0} for i in range(29)}
            self.pin_states['LED'] = {'mode': 'OUT', 'value': 0}
            return "OK: ALL_OFF"

    def get_info(self):
        """Get board status, CPU frequency, active pin list, and diagnostics."""
        resp = self.send_command("STATUS")
        return resp

    def close(self):
        """Close serial connection."""
        with self.lock:
            if self.ser and self.ser.is_open:
                try:
                    self.ser.close()
                except Exception:
                    pass
                self.ser = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

