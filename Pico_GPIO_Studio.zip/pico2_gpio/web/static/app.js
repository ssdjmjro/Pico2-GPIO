// Pico GPIO Web Studio Client

const PICO_PINS = [
    { num: 1, gp: 0, name: "GP0", side: "left" },
    { num: 2, gp: 1, name: "GP1", side: "left" },
    { num: 3, gp: null, name: "GND", side: "left" },
    { num: 4, gp: 2, name: "GP2", side: "left" },
    { num: 5, gp: 3, name: "GP3", side: "left" },
    { num: 6, gp: 4, name: "GP4", side: "left" },
    { num: 7, gp: 5, name: "GP5", side: "left" },
    { num: 8, gp: null, name: "GND", side: "left" },
    { num: 9, gp: 6, name: "GP6", side: "left" },
    { num: 10, gp: 7, name: "GP7", side: "left" },
    { num: 11, gp: 8, name: "GP8", side: "left" },
    { num: 12, gp: 9, name: "GP9", side: "left" },
    { num: 13, gp: null, name: "GND", side: "left" },
    { num: 14, gp: 10, name: "GP10", side: "left" },
    { num: 15, gp: 11, name: "GP11", side: "left" },
    { num: 16, gp: 12, name: "GP12", side: "left" },
    { num: 17, gp: 13, name: "GP13", side: "left" },
    { num: 18, gp: null, name: "GND", side: "left" },
    { num: 19, gp: 14, name: "GP14", side: "left" },
    { num: 20, gp: 15, name: "GP15", side: "left" },

    { num: 21, gp: 16, name: "GP16", side: "right" },
    { num: 22, gp: 17, name: "GP17", side: "right" },
    { num: 23, gp: null, name: "GND", side: "right" },
    { num: 24, gp: 18, name: "GP18", side: "right" },
    { num: 25, gp: 19, name: "GP19", side: "right" },
    { num: 26, gp: 20, name: "GP20", side: "right" },
    { num: 27, gp: 21, name: "GP21", side: "right" },
    { num: 28, gp: null, name: "GND", side: "right" },
    { num: 29, gp: 22, name: "GP22", side: "right" },
    { num: 30, gp: null, name: "RUN", side: "right" },
    { num: 31, gp: 26, name: "GP26", side: "right" },
    { num: 32, gp: 27, name: "GP27", side: "right" },
    { num: 33, gp: null, name: "AGND", side: "right" },
    { num: 34, gp: 28, name: "GP28", side: "right" },
    { num: 35, gp: null, name: "VREF", side: "right" },
    { num: 36, gp: null, name: "3V3", side: "right" },
    { num: 37, gp: null, name: "3V3_EN", side: "right" },
    { num: 38, gp: null, name: "GND", side: "right" },
    { num: 39, gp: null, name: "VSYS", side: "right" },
    { num: 40, gp: null, name: "VBUS", side: "right" }
];

let selectedPin = 15;
let currentMode = "OUT";
let adcHistory = [];
let blinkerTimer = null;
let servoTimer = null;
let servoSweepDir = 1;
let sequenceRunning = false;
let sequenceTimer = null;

// Initial Setup
document.addEventListener("DOMContentLoaded", () => {
    buildBoard();
    populatePinSelect();
    setupEventListeners();
    setupOscilloscope();
    buildHexGrid();
    startStatusPolling();
});

function buildBoard() {
    const leftCol = document.getElementById("left-pins");
    const rightCol = document.getElementById("right-pins");
    leftCol.innerHTML = "";
    rightCol.innerHTML = "";

    // Left pins 1-20
    PICO_PINS.filter(p => p.side === "left").forEach(p => {
        const node = createPinNode(p);
        leftCol.appendChild(node);
    });

    // Right pins 40 down to 21
    PICO_PINS.filter(p => p.side === "right").reverse().forEach(p => {
        const node = createPinNode(p);
        rightCol.appendChild(node);
    });
}

function createPinNode(p) {
    const node = document.createElement("div");
    node.className = "pin-node";
    node.id = `pin-node-${p.num}`;
    node.dataset.num = p.num;
    node.dataset.gp = p.gp;

    if (p.gp === selectedPin) node.classList.add("selected");

    const pad = document.createElement("div");
    pad.className = "pin-pad";
    pad.textContent = p.num;

    const label = document.createElement("div");
    label.className = "pin-label";
    label.textContent = p.name;

    node.appendChild(pad);
    node.appendChild(label);

    node.addEventListener("click", () => {
        if (p.gp !== null) {
            selectPin(p.gp);
        }
    });

    return node;
}

function populatePinSelect() {
    const select = document.getElementById("pin-select");
    select.innerHTML = "";

    const ledOpt = document.createElement("option");
    ledOpt.value = "LED";
    ledOpt.textContent = "LED (GP25 - Onboard LED)";
    select.appendChild(ledOpt);

    for (let gp = 0; gp < 29; gp++) {
        const opt = document.createElement("option");
        opt.value = gp;
        opt.textContent = `GP${gp}`;
        if (gp === selectedPin) opt.selected = true;
        select.appendChild(opt);
    }
}

function selectPin(gp) {
    selectedPin = gp;
    const select = document.getElementById("pin-select");
    select.value = gp;

    // Highlight on board
    document.querySelectorAll(".pin-node").forEach(n => {
        n.classList.toggle("selected", n.dataset.gp == gp);
    });
}

function setupEventListeners() {
    // Pin select dropdown
    document.getElementById("pin-select").addEventListener("change", (e) => {
        selectPin(e.target.value === "LED" ? "LED" : parseInt(e.target.value));
    });

    // Top Navigation Tabs
    document.querySelectorAll(".tab-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
            document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
            btn.classList.add("active");
            document.getElementById(btn.dataset.tab).classList.add("active");
        });
    });

    // Mode Switcher Pills
    document.querySelectorAll(".mode-pills .pill").forEach(pill => {
        pill.addEventListener("click", () => {
            document.querySelectorAll(".mode-pills .pill").forEach(p => p.classList.remove("active"));
            document.querySelectorAll(".subpanel").forEach(s => s.classList.remove("active"));
            pill.classList.add("active");
            currentMode = pill.dataset.mode;
            document.getElementById(`subpanel-${currentMode.toLowerCase()}`).classList.add("active");
        });
    });

    // Quick LED Toggle
    document.getElementById("btn-quick-led").addEventListener("click", () => {
        postAPI("/api/led", { state: "toggle" });
    });

    // Emergency Stop
    document.getElementById("btn-emergency").addEventListener("click", () => {
        postAPI("/api/all_off", {});
        logTerminal("🛑 [SAFE STOP] All pins parked & outputs disabled.");
    });

    // Digital Out Actions
    document.getElementById("btn-out-high").addEventListener("click", () => {
        postAPI("/api/write", { pin: selectedPin, val: 1 });
        updatePinBoardVisual(selectedPin, "state-high");
    });
    document.getElementById("btn-out-low").addEventListener("click", () => {
        postAPI("/api/write", { pin: selectedPin, val: 0 });
        updatePinBoardVisual(selectedPin, "");
    });
    document.getElementById("btn-out-toggle").addEventListener("click", () => {
        postAPI("/api/toggle", { pin: selectedPin }).then(data => {
            if (data.ok) updatePinBoardVisual(selectedPin, data.val ? "state-high" : "");
        });
    });

    // Pulses
    document.querySelectorAll(".btn-pulse").forEach(b => {
        b.addEventListener("click", () => {
            const ms = parseInt(b.dataset.ms);
            postAPI("/api/write", { pin: selectedPin, val: 1 });
            updatePinBoardVisual(selectedPin, "state-high");
            setTimeout(() => {
                postAPI("/api/write", { pin: selectedPin, val: 0 });
                updatePinBoardVisual(selectedPin, "");
            }, ms);
        });
    });

    // Blinker
    document.getElementById("chk-blinker").addEventListener("change", (e) => {
        if (e.target.checked) {
            const spd = parseInt(document.getElementById("rng-blinker-speed").value);
            let state = 0;
            blinkerTimer = setInterval(() => {
                state = state ? 0 : 1;
                postAPI("/api/write", { pin: selectedPin, val: state });
                updatePinBoardVisual(selectedPin, state ? "state-high" : "");
            }, spd);
            document.getElementById("blinker-status").textContent = "Blinker RUNNING";
        } else {
            clearInterval(blinkerTimer);
            blinkerTimer = null;
            postAPI("/api/write", { pin: selectedPin, val: 0 });
            updatePinBoardVisual(selectedPin, "");
            document.getElementById("blinker-status").textContent = "Blinker OFF";
        }
    });

    // PWM Controls
    const rngFreq = document.getElementById("rng-pwm-freq");
    const rngDuty = document.getElementById("rng-pwm-duty");
    rngFreq.addEventListener("input", (e) => document.getElementById("pwm-freq-val").textContent = e.target.value);
    rngDuty.addEventListener("input", (e) => document.getElementById("pwm-duty-val").textContent = e.target.value);

    document.querySelectorAll("#subpanel-pwm .chip[data-freq]").forEach(c => {
        c.addEventListener("click", () => {
            rngFreq.value = c.dataset.freq;
            document.getElementById("pwm-freq-val").textContent = c.dataset.freq;
        });
    });
    document.querySelectorAll("#subpanel-pwm .chip[data-duty]").forEach(c => {
        c.addEventListener("click", () => {
            rngDuty.value = c.dataset.duty;
            document.getElementById("pwm-duty-val").textContent = c.dataset.duty;
        });
    });

    document.getElementById("btn-apply-pwm").addEventListener("click", () => {
        const freq = parseInt(rngFreq.value);
        const duty = parseFloat(rngDuty.value);
        postAPI("/api/pwm", { pin: selectedPin, freq, duty });
        updatePinBoardVisual(selectedPin, "state-pwm");
    });
    document.getElementById("btn-stop-pwm").addEventListener("click", () => {
        postAPI("/api/pwm_stop", { pin: selectedPin });
        updatePinBoardVisual(selectedPin, "");
    });

    // Servo Controls
    const rngServo = document.getElementById("rng-servo-angle");
    rngServo.addEventListener("input", (e) => {
        document.getElementById("servo-angle-val").textContent = e.target.value;
        postAPI("/api/servo", { pin: selectedPin, angle: parseFloat(e.target.value) });
        updatePinBoardVisual(selectedPin, "state-servo");
    });
    document.querySelectorAll("#subpanel-servo .chip[data-angle]").forEach(c => {
        c.addEventListener("click", () => {
            rngServo.value = c.dataset.angle;
            document.getElementById("servo-angle-val").textContent = c.dataset.angle;
            postAPI("/api/servo", { pin: selectedPin, angle: parseFloat(c.dataset.angle) });
            updatePinBoardVisual(selectedPin, "state-servo");
        });
    });

    // Servo Auto Sweep
    document.getElementById("chk-servo-sweep").addEventListener("change", (e) => {
        if (e.target.checked) {
            servoTimer = setInterval(() => {
                let ang = parseFloat(rngServo.value) + servoSweepDir * 3;
                if (ang >= 180) { ang = 180; servoSweepDir = -1; }
                if (ang <= 0) { ang = 0; servoSweepDir = 1; }
                rngServo.value = ang;
                document.getElementById("servo-angle-val").textContent = Math.round(ang);
                postAPI("/api/servo", { pin: selectedPin, angle: ang });
            }, 40);
        } else {
            clearInterval(servoTimer);
            servoTimer = null;
        }
    });

    // ADC Sample
    document.getElementById("btn-sample-adc").addEventListener("click", () => {
        fetch(`/api/adc?pin=${selectedPin >= 26 && selectedPin <= 28 ? selectedPin : 26}`)
            .then(r => r.json())
            .then(d => {
                document.getElementById("adc-volts-big").textContent = `${d.volts.toFixed(3)} V`;
                document.getElementById("adc-raw-sub").textContent = `Raw: ${d.raw} / 65535`;
            });
    });

    // I2C Scan
    document.getElementById("btn-i2c-scan").addEventListener("click", () => {
        const sda = document.getElementById("i2c-sda").value;
        const scl = document.getElementById("i2c-scl").value;
        document.getElementById("i2c-status-text").textContent = "Scanning I2C bus...";
        
        document.querySelectorAll(".hex-cell").forEach(c => c.classList.remove("found"));

        fetch(`/api/i2c_scan?sda=${sda}&scl=${scl}`)
            .then(r => r.json())
            .then(d => {
                const devs = d.devices || [];
                if (devs.length === 0) {
                    document.getElementById("i2c-status-text").textContent = "No I2C devices detected.";
                } else {
                    document.getElementById("i2c-status-text").textContent = `Found ${devs.length} device(s): ${devs.join(", ")}`;
                    devs.forEach(addrStr => {
                        const cell = document.getElementById(`hex-${addrStr.toLowerCase()}`);
                        if (cell) cell.classList.add("found");
                    });
                }
            });
    });

    // Console Raw Send
    document.getElementById("btn-send-raw").addEventListener("click", sendRawCommand);
    document.getElementById("console-input").addEventListener("keypress", (e) => {
        if (e.key === "Enter") sendRawCommand();
    });
    document.getElementById("btn-clear-console").addEventListener("click", () => {
        document.getElementById("console-logs").textContent = "";
    });

    // Automation Sequences
    document.getElementById("btn-seq-run").addEventListener("click", startAutomationSequence);
    document.getElementById("btn-seq-stop").addEventListener("click", stopAutomationSequence);
}

function updatePinBoardVisual(gp, stateClass) {
    document.querySelectorAll(`.pin-node[data-gp="${gp}"]`).forEach(n => {
        n.className = "pin-node" + (n.classList.contains("selected") ? " selected" : "") + (stateClass ? " " + stateClass : "");
    });
}

function postAPI(url, data) {
    return fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(r => r.json())
    .then(res => {
        logTerminal(`TX ➔ ${url} ${JSON.stringify(data)}\nRX ⇠ ${JSON.stringify(res)}`);
        return res;
    })
    .catch(err => {
        logTerminal(`🔴 ERR: ${err}`);
    });
}

function logTerminal(msg) {
    const box = document.getElementById("console-logs");
    const t = new Date().toLocaleTimeString();
    box.textContent += `[${t}] ${msg}\n`;
    box.scrollTop = box.scrollHeight;
}

function sendRawCommand() {
    const input = document.getElementById("console-input");
    const cmd = input.value.trim();
    if (!cmd) return;
    input.value = "";
    postAPI("/api/raw", { cmd });
}

// Oscilloscope Rendering
function setupOscilloscope() {
    const canvas = document.getElementById("scope-canvas");
    const ctx = canvas.getContext("2d");

    function renderScope() {
        ctx.fillStyle = "#080a0f";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Grid
        ctx.strokeStyle = "rgba(56, 189, 248, 0.15)";
        ctx.lineWidth = 1;
        for (let y = 0; y < canvas.height; y += 40) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
        }

        // Trace
        if (adcHistory.length > 1) {
            ctx.strokeStyle = "#38bdf8";
            ctx.lineWidth = 2.5;
            ctx.beginPath();
            const step = canvas.width / (adcHistory.length - 1);
            adcHistory.forEach((v, i) => {
                const y = canvas.height - (v / 3.3) * (canvas.height - 20) - 10;
                if (i === 0) ctx.moveTo(0, y);
                else ctx.lineTo(i * step, y);
            });
            ctx.stroke();
        }

        requestAnimationFrame(renderScope);
    }
    renderScope();

    document.getElementById("btn-scope-clear").addEventListener("click", () => {
        adcHistory = [];
    });
}

function buildHexGrid() {
    const grid = document.getElementById("i2c-hex-grid");
    grid.innerHTML = "";
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 16; c++) {
            const addr = (r << 4) | c;
            const cell = document.createElement("div");
            cell.className = "hex-cell";
            const hex = `0x${addr.toString(16).padStart(2, '0')}`;
            cell.id = `hex-${hex}`;
            cell.textContent = addr.toString(16).toUpperCase().padStart(2, '0');
            if (addr < 0x08 || addr > 0x77) cell.style.opacity = "0.2";
            grid.appendChild(cell);
        }
    }
}

function startStatusPolling() {
    setInterval(() => {
        fetch("/api/status")
            .then(r => r.json())
            .then(d => {
                const badge = document.getElementById("conn-badge");
                if (d.mock) {
                    badge.className = "badge badge-sim";
                    badge.textContent = "🔮 Simulation Mode";
                } else if (d.connected) {
                    badge.className = "badge badge-connected";
                    badge.textContent = `🟢 Connected: ${d.port}`;
                } else {
                    badge.className = "badge badge-disconnected";
                    badge.textContent = "🔴 Disconnected";
                }

                document.getElementById("temp-badge").textContent = `${d.temp_c.toFixed(1)} °C`;
                document.getElementById("chip-temp").textContent = `${d.temp_c.toFixed(1)} °C`;
                document.getElementById("board-led").classList.toggle("led-on", Boolean(d.led));
            })
            .catch(() => {
                document.getElementById("conn-badge").className = "badge badge-disconnected";
                document.getElementById("conn-badge").textContent = "🔴 Disconnected";
            });

        // Continuous ADC sampling if enabled
        if (document.getElementById("chk-stream-adc").checked) {
            const pin = selectedPin >= 26 && selectedPin <= 28 ? selectedPin : 26;
            fetch(`/api/adc?pin=${pin}`)
                .then(r => r.json())
                .then(d => {
                    document.getElementById("adc-volts-big").textContent = `${d.volts.toFixed(3)} V`;
                    document.getElementById("adc-raw-sub").textContent = `Raw: ${d.raw} / 65535`;
                    adcHistory.push(d.volts);
                    if (adcHistory.length > 80) adcHistory.shift();

                    document.getElementById("scope-now").textContent = `Now: ${d.volts.toFixed(2)}V`;
                    document.getElementById("scope-min").textContent = `Min: ${Math.min(...adcHistory).toFixed(2)}V`;
                    document.getElementById("scope-max").textContent = `Max: ${Math.max(...adcHistory).toFixed(2)}V`;
                });
        }
    }, 150);
}

function startAutomationSequence() {
    sequenceRunning = true;
    let step = 0;
    const steps = [
        () => postAPI("/api/write", { pin: 15, val: 1 }),
        () => postAPI("/api/write", { pin: 15, val: 0 }),
        () => postAPI("/api/write", { pin: 14, val: 1 }),
        () => postAPI("/api/write", { pin: 14, val: 0 }),
        () => postAPI("/api/led", { state: "toggle" })
    ];

    sequenceTimer = setInterval(() => {
        if (!sequenceRunning) return;
        steps[step % steps.length]();
        step++;
    }, 200);
}

function stopAutomationSequence() {
    sequenceRunning = false;
    if (sequenceTimer) {
        clearInterval(sequenceTimer);
        sequenceTimer = null;
    }
}
