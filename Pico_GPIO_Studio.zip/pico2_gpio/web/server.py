#!/usr/bin/env python3
"""
Pico GPIO Web Studio Server
Fast, lightweight REST & WebSocket-compatible HTTP server using standard Python library.
"""

import os
import sys
import json
import time
import threading
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from pico_gpio import PicoGPIO, PicoGPIOError

pico_instance = None
pico_lock = threading.Lock()


def get_pico():
    global pico_instance
    with pico_lock:
        if pico_instance is None:
            try:
                pico_instance = PicoGPIO()
            except Exception:
                pico_instance = PicoGPIO(mock=True)
        return pico_instance


class PicoWebHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        static_dir = os.path.join(os.path.dirname(__file__), "static")
        super().__init__(*args, directory=static_dir, **kwargs)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/"):
            self._handle_api_get(parsed)
        else:
            super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/"):
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length).decode('utf-8') if length > 0 else "{}"
            try:
                data = json.loads(body)
            except Exception:
                data = {}
            self._handle_api_post(parsed, data)
        else:
            self.send_error(404, "Not Found")

    def _send_json(self, data, code=200):
        resp_bytes = json.dumps(data).encode('utf-8')
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(resp_bytes)))
        self.end_headers()
        self.wfile.write(resp_bytes)

    def _handle_api_get(self, parsed):
        p = get_pico()
        path = parsed.path
        qs = parse_qs(parsed.query)

        try:
            if path == "/api/status":
                info = p.get_info()
                temp = p.get_internal_temp()
                self._send_json({
                    'connected': p.is_connected(),
                    'port': p.port,
                    'mock': p.mock,
                    'temp_c': temp,
                    'info': info,
                    'led': p.led_state,
                    'pins': p.pin_states
                })
            elif path == "/api/temp":
                temp = p.get_internal_temp()
                self._send_json({'temp_c': temp, 'temp_f': temp * 9/5 + 32})
            elif path == "/api/read":
                pin = qs.get('pin', ['15'])[0]
                pull = qs.get('pull', ['none'])[0]
                if pull == 'up':
                    p.pin_mode(pin, "IN_PULLUP")
                elif pull == 'down':
                    p.pin_mode(pin, "IN_PULLDOWN")
                val = p.digital_read(pin)
                self._send_json({'pin': pin, 'val': val})
            elif path == "/api/adc":
                pin = qs.get('pin', ['26'])[0]
                data = p.analog_read_full(pin)
                self._send_json({'pin': pin, 'raw': data['raw'], 'volts': data['volts']})
            elif path == "/api/i2c_scan":
                sda = int(qs.get('sda', ['4'])[0])
                scl = int(qs.get('scl', ['5'])[0])
                devs = p.i2c_scan(sda, scl)
                self._send_json({'sda': sda, 'scl': scl, 'devices': devs})
            else:
                self._send_json({'error': f"Unknown API endpoint {path}"}, code=404)
        except Exception as e:
            self._send_json({'error': str(e)}, code=500)

    def _handle_api_post(self, parsed, data):
        p = get_pico()
        path = parsed.path

        try:
            if path == "/api/write":
                pin = data.get('pin', 15)
                val = data.get('val', 0)
                p.pin_mode(pin, "OUT")
                resp = p.digital_write(pin, val)
                self._send_json({'ok': True, 'pin': pin, 'val': val, 'resp': resp})
            elif path == "/api/toggle":
                pin = data.get('pin', 15)
                val = p.toggle(pin)
                self._send_json({'ok': True, 'pin': pin, 'val': val})
            elif path == "/api/led":
                state = data.get('state')
                resp = p.led(state)
                self._send_json({'ok': True, 'led': p.led_state, 'resp': resp})
            elif path == "/api/pwm":
                pin = data.get('pin', 15)
                freq = data.get('freq', 1000)
                duty = data.get('duty', 50.0)
                resp = p.pwm(pin, freq, duty)
                self._send_json({'ok': True, 'pin': pin, 'freq': freq, 'duty': duty, 'resp': resp})
            elif path == "/api/pwm_stop":
                pin = data.get('pin', 15)
                resp = p.pwm_stop(pin)
                self._send_json({'ok': True, 'pin': pin, 'resp': resp})
            elif path == "/api/servo":
                pin = data.get('pin', 14)
                angle = data.get('angle', 90.0)
                resp = p.servo(pin, angle)
                self._send_json({'ok': True, 'pin': pin, 'angle': angle, 'resp': resp})
            elif path == "/api/all_off":
                resp = p.all_off()
                self._send_json({'ok': True, 'resp': resp})
            elif path == "/api/raw":
                cmd = data.get('cmd', '')
                resp = p.send_command(cmd)
                self._send_json({'ok': True, 'cmd': cmd, 'resp': resp})
            else:
                self._send_json({'error': f"Unknown API endpoint {path}"}, code=404)
        except Exception as e:
            self._send_json({'error': str(e)}, code=500)


def run_web_server(port=5500):
    server = HTTPServer(("0.0.0.0", port), PicoWebHandler)
    print(f"\033[1m\033[92m🚀 Pico GPIO Web Studio running at: http://localhost:{port}\033[0m")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Web Studio server...")
        server.server_close()


if __name__ == "__main__":
    p = 5500
    if len(sys.argv) > 1:
        try:
            p = int(sys.argv[1])
        except ValueError:
            pass
    run_web_server(p)
