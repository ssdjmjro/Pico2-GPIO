#!/usr/bin/env bash
# ==========================================================
# Pico 2 GPIO Activation Script
# ==========================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN="\033[92m"
CYAN="\033[96m"
YELLOW="\033[93m"
RED="\033[91m"
BOLD="\033[1m"
RESET="\033[0m"

echo -e "${BOLD}${CYAN}================================================${RESET}"
echo -e "${BOLD}${CYAN}   ⚡ Pico 2 (RP2350) Ubuntu GPIO Activation    ${RESET}"
echo -e "${BOLD}${CYAN}================================================${RESET}"

# Check if Pico 2 is in BOOTSEL mode
if [ -d "/run/media/$USER/RP2350" ] || [ -d "/run/media/$USER/RPI-RP2" ] || [ -d "/media/$USER/RP2350" ] || [ -d "/media/$USER/RPI-RP2" ]; then
    echo -e "${YELLOW}Pico 2 is in BOOTLOADER mode. Flashing firmware...${RESET}"
    bash "$DIR/flash_pico2.sh"
    sleep 2
fi

# Run diagnostics and self-test
echo -e "${CYAN}Checking connection and activating GPIO controller...${RESET}"
if python3 "$DIR/pico-gpio" test; then
    echo -e "\n${BOLD}${GREEN}==================================================================${RESET}"
    echo -e "${BOLD}${GREEN}   ✓ Pico 2 GPIO is now ACTIVATED and ready for use!             ${RESET}"
    echo -e "${BOLD}${GREEN}==================================================================${RESET}"
    echo -e "\n🚀 ${BOLD}How to control your Pico:${RESET}"
    echo -e "  1. ${BOLD}Desktop GUI App:${RESET}      Run ${CYAN}pico-studio${RESET} or click 'Pico GPIO Studio' on Desktop"
    echo -e "  2. ${BOLD}Web Studio Dashboard:${RESET} Run ${CYAN}pico-web${RESET} (Opens http://localhost:5500)"
    echo -e "  3. ${BOLD}CLI Terminal:${RESET}         Run ${CYAN}pico-gpio status / led / write / read${RESET}"
    echo -e "  4. ${BOLD}Python Scripts:${RESET}       ${CYAN}import pico_gpio${RESET}\n"
else
    echo -e "${RED}✗ Failed to activate Pico 2. Please check USB cable connection.${RESET}"
    exit 1
fi
