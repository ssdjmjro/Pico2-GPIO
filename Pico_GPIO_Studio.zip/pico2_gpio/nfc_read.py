#!/usr/bin/env python3
"""
Pico 2 PN532 NFC / RFID Card Reader
Continuously polls for 13.56 MHz RFID / NFC cards, tags, keyfobs, and smartphones.
"""
import serial
import time
import sys

def main():
    print("\033[1m\033[96m====================================================\033[0m")
    print("\033[1m\033[96m      ⚡ Raspberry Pi Pico 2 + PN532 NFC Scanner    \033[0m")
    print("\033[1m\033[96m====================================================\033[0m")
    
    try:
        ser = serial.Serial('/dev/ttyACM0', 115200, timeout=1)
    except Exception as e:
        print(f"\033[91mError connecting to /dev/ttyACM0:\033[0m {e}")
        sys.exit(1)

    ser.dtr = True
    ser.rts = False
    
    # Enter raw REPL
    ser.write(b'\x03\x03\x01')
    time.sleep(0.1)
    ser.reset_input_buffer()
    
    # MicroPython script to poll PN532
    scanner_code = """
import time, machine, sys

i2c = machine.I2C(0, sda=machine.Pin(4), scl=machine.Pin(5), freq=100000)
PN532_ADDR = 0x24

def scan_card():
    # Wakeup / SAMConfig
    try:
        i2c.writeto(PN532_ADDR, bytes([0x00, 0x00, 0xFF, 0x03, 0xFD, 0xD4, 0x14, 0x01, 0x17, 0x00]))
        time.sleep(0.04)
        # InListPassiveTarget
        i2c.writeto(PN532_ADDR, bytes([0x00, 0x00, 0xFF, 0x04, 0xFC, 0xD4, 0x4A, 0x01, 0x00, 0xE1, 0x00]))
        time.sleep(0.06)
        resp = i2c.readfrom(PN532_ADDR, 24)
        if len(resp) >= 19 and resp[7] == 0xD5 and resp[8] == 0x4B and resp[9] > 0:
            uid_len = resp[14]
            uid = resp[15:15 + uid_len]
            return ":".join(f"{b:02X}" for b in uid)
    except Exception:
        pass
    return None

print("NFC_INIT_OK")
last = None
while True:
    card = scan_card()
    if card and card != last:
        print("CARD_DETECTED:" + card)
        last = card
        time.sleep(0.5)
    elif not card:
        last = None
    time.sleep(0.1)
"""
    ser.write(scanner_code.encode() + b'\x04')
    print("\033[92m📡 Scanner started! Hold a card, keyfob, or phone near the PN532 antenna...\033[0m")
    print("\033[90m(Press Ctrl+C to exit)\033[0m\n")
    
    try:
        while True:
            line = ser.readline().decode(errors='replace').strip()
            if "CARD_DETECTED:" in line:
                uid = line.split("CARD_DETECTED:")[1]
                print(f"\033[1m\033[92m🏷️  Card Detected! UID: \033[93m{uid}\033[0m")
            elif "NFC_INIT_OK" in line:
                pass
            elif line:
                pass
    except KeyboardInterrupt:
        print("\n\033[93mStopping NFC scanner...\033[0m")
    finally:
        # Exit raw REPL and reboot into normal GPIO mode
        ser.write(b'\x03\x03\x02\x04')
        time.sleep(0.3)
        ser.close()
        print("\033[92m✓ Pico 2 restored to normal GPIO mode.\033[0m")

if __name__ == "__main__":
    main()
